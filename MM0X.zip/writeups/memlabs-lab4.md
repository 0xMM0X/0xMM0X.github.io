+++
author = ["MMOX ","xElessaway"]
title = "MemLabs Writeup - Lab 4 (Obsession - Medium) "
date = "2021-03-01"
description = "Digital Forensic Memory Dump challenges Writeups "
tags = [
    "MemLabs",
    "Writeups",
    "Digital Forensics",
]
categories = [
    "Writeups",
    "DFIR",
	"Memory",
	"Digital Forensics",
]

favorite= true
show_comments= true
showToc= true
Tocopen= false
+++
![MemLabs-logo](/postImgs/MemLabs-logo.png)


|Lab   |   Challenge link   | difficulty| Writeup link|
|------|--------------------|------|-------------------------|
|Lab 1 | [Beginner's Luck](https://mega.nz/#!6l4BhKIb!l8ATZoliB_ULlvlkESwkPiXAETJEF7p91Gf9CWuQI70) | Easy |[Lab 1 ](https://www.mmox.me/posts/writeups/memlabs-lab1/)|
|Lab 2 | [A New World ](https://mega.nz/#!ChoDHaja!1XvuQd49c7-7kgJvPXIEAst-NXi8L3ggwienE1uoZTk)   | Easy |[Lab 2 ](https://www.mmox.me/posts/writeups/memlabs-lab2/)|
|Lab 3 | [The Evil's Den](https://mega.nz/#!2ohlTAzL!1T5iGzhUWdn88zS1yrDJA06yUouZxC-VstzXFSRuzVg) |Easy - Medium|[Lab 3 ](https://www.mmox.me/posts/writeups/memlabs-lab3/)|
|Lab 4 | [Obsession](https://mega.nz/#!Tx41jC5K!ifdu9DUair0sHncj5QWImJovfxixcAY-gt72mCXmYrE)      |Medium|[Lab 4 ](https://www.mmox.me/posts/writeups/memlabs-lab4/)|
|Lab 5 | [Black Tuesday](https://mega.nz/#!Ps5ViIqZ!UQtKmUuKUcqqtt6elP_9OJtnAbpwwMD7lVKN1iWGoec)   | Medium - Hard |[Lab 5 ](https://www.mmox.me/posts/writeups/memlabs-lab5/)|
|Lab 6 | [The Reckoning](https://mega.nz/#!C0pjUKxI!LnedePAfsJvFgD-Uaa4-f1Tu0kl5bFDzW6Mn2Ng6pnM)   |Hard|[Lab 6 ](https://www.mmox.me/posts/writeups/memlabs-lab6/)|

# Challenge description

	My system was recently compromised. The Hacker stole a lot of information but he also deleted a very
	important file of mine. I have no idea on how to recover it. The only evidence we have,
	at this point of time is this memory dump. Please help me.
	
* Note: This challenge is composed of only 1 flag.
* The flag format for this lab is: inctf{s0me_l33t_Str1ng}

# Writeup

I started thinking it's hard but the description helped me alot espically 
	
	"deleted a very	important file of mine"
	
so i will use file scan and mft parser but let's check the profile first

	./volatility.exe -f MemoryDump_Lab4.raw imageinfo

![lab4-1](/postImgs/lab4/1.png)

so it's "Win7SP1x64"

doing file scan and greping text files there was 1 named "Important.txt"
	
	./volatility.exe -f MemoryDump_Lab4.raw --profile=Win7SP1x64 filescan |grep ".txt"
	
![lab4-2](/postImgs/lab4/2.png)

so i tried to dump it 
	
	./volatility.exe -f MemoryDump_Lab4.raw --profile=Win7SP1x64 dumpfiles -Q 0x000000003fc398d0 -D .

but nothing happend so i tried mftparser and greped the file name 
	
	./volatility.exe -f MemoryDump_Lab4.raw --profile=Win7SP1x64 mftparser | grep -C 20 Important.txt
	
yup it was easy as i expected 

![lab4-3](/postImgs/lab4/3.png)

and like that i got the flag 

	 inctf{1_is_n0t_EQu4l_7o_2_bUt_th1s_d0s3nt_m4ke_s3ns3} 
