+++
author = "MMOX "
title = "Let's Defend - RanDev"
date = "2023-03-06"
description = "Digital Forensic Memory Dump challenge Writeup "
tags = [
    "Lets defend",
    "Writeups",
    "Digital Forensics",
	"Memory",
	"Ransomware"
]
categories = [
    "Writeups",
    "DFIR",
	"Malware Analysis",
	"Digital Forensics",
]

favorite= true
show_comments= true
showToc= true
Tocopen= false
draft= true

+++

![logo](/postImgs/letsdefend/RanDev/logo.png)

# Description 

```
We hired a full stack developer but seems he faked all his experience and he is just lazy developer and got attacked by a weird ransomware can you investigate what happened ?
```

# Questions 

```
Q1: What is the bitcoin wallet address that the hacker left
Q2: What is the SHA256 of the Ransomware
Q3: What is the full URL that downloaded the ransomware?
Q4: What function executed the ransomware?
Q5: What is the extension of the ransomware?
Q6: The Ransomware contain a fake key to encrypt the files?
Q7: What is the KEY that encrypted the data?
Q8: After getting the correct key can you decrypt Tasks.txt and tell me how many tasks there are?
```

# Tools
```
Tools Required
1- Volatility
2- IDA Pro or any disassembler
3- Command Line
4- Scripting or Cyberchef
5- DB Browser
```

# Writeup

in this challenge I got a memory dump. 
![1](/postImgs/letsdefend/RanDev/1.png)

so let's check the operating system of the memory.

```
python3 vol.py -f RanDev.vmem windows.info
```

![2](/postImgs/letsdefend/RanDev/2.png)

well it seems it's Windows10. so let's check the process in this dump.

```
python3 vol.py -f RanDev.vmem windows.psscan
```

![3](/postImgs/letsdefend/RanDev/3.png)

after wenting through the process I didn't any suspicious process that ran on the system. let's see the first hint of the first question
```
Q1 Hint: Did you check desktop?
```

the hint says I need to check the desktop. so let's filescan and check desktop.

```
python3 vol.py -f RanDev.vmem windows.filescan > files.txt
strings files.txt | grep -i "Desktop"
```

![4](/postImgs/letsdefend/RanDev/4.png)
okay now I got all files on the desktop on the system and I noticed that there is a file called " Tasks.txt" so let's dump this file and check what does it contain.

```
python3 vol.py -f RanDev.vmem windows.dumpfiles --virtaddr 0xa001c1a9fb60
```

![5](/postImgs/letsdefend/RanDev/5.png)


it seems the file is encrypted so I need to keep checking the desktop to find another thing.

![6](/postImgs/letsdefend/RanDev/6.png)

and yes I noticed another file called "note.txt" so let's dump and hope we find something useful this time.

```
python3 vol.py -f RanDev.vmem windows.dumpfiles --virtaddr 0xa001c401ed40
cat file.0xa001c401ed40.0xa001c4d52850.DataSectionObject.note.txt.dat
```

![7](/postImgs/letsdefend/RanDev/7.png)

and yes we got the bitcoin wallet addess which is 

```
Q1 Answer: bc1qwe5qxdj7aekpj8aeeeey6tf5hjzugk3jkax6lm
```

Now let's head to the second question and it says 

```
Q2: What is the SHA256 of the Ransomware
```

But I don't know where can I find the Ransomware so after checking the Hint

```
Q2 Hint: executable file!
```

the hint says executable file so let's try to grep any ".exe" file in the files we got

```
strings files.txt | grep -i ".exe"
```

![8](/postImgs/letsdefend/RanDev/8.png)

well i noticed that there is an executable file called "R.exe" and I guess it's it let' dump it and check it on virustotal

```
python3 vol.py -f RanDev.vmem windows.dumpfiles --virtaddr 0xa001c5439960
```

![9](/postImgs/letsdefend/RanDev/9.png)

well it seems it's really suspicious so let's get the SHA256 and submit it.
```
sha256sum file.0xa001c5439960.0xa001c4558110.DataSectionObject.R.exe.dat
```

and yes the Answer for the second question is 
```
Q2 Answer: d22aff59eae7201e6a4f82dbe99173c7103665beaa0860f81db7130f38c99a35
```

Let's head to the third question which is

```
Q3: What is the full URL that downloaded the ransomware?
```

Hmmmm how can I get the URL if I got the netstat or netscan I won't able to get the full URL but there is another way we can use by checking the history of the browser.
so the process I saw there was "Microsoft Edge" ran on the PC. so let's google how to find the history in files system and I got it the directory of it which is.
```
\Users\USERPROFILE\AppData\Local\Microsoft\Edge\User Data\Default\History
```

so let's back to files and dump that file.

```
python3 vol.py -f RanDev.vmem windows.dumpfiles --virtaddr 0xa001c541ea20
```

after dumping it I checked the history through "DB Browser".

![10](/postImgs/letsdefend/RanDev/10.png)

I found out that the last URL he visited was "localhost/login.php". so let's check the hint of the third question.

```
Q3 Hint: The developer ran local server
```

Well well well let's check the files of that ran server. I checked that there is xampp already installed and ran on the PC from the process.
![11](/postImgs/letsdefend/RanDev/11.png)

so let's check the directory of the server files.

```
C:\xampp\htdocs
```

```
strings files.txt | grep -i "htdocs"
```
![12](/postImgs/letsdefend/RanDev/12.png)

well well well we got some interesting files let's dump the login and  authentication.php
```
python3 vol.py -f RanDev.vmem windows.dumpfiles --virtaddr 0xa001c517d3d0
python3 vol.py -f RanDev.vmem windows.dumpfiles --virtaddr 0xa001c54102e0
```

![13](/postImgs/letsdefend/RanDev/13.png)

the login.php wasn't very interesting so much so let's check authentication.php.

![14](/postImgs/letsdefend/RanDev/14.png)

well well well this is very interesting. fileURL vairable seems base64 so let's decode it.

![15](/postImgs/letsdefend/RanDev/15.png)

now we got the answer of the third question which is.

```
Q3 Answer: http://192.168.235.137/download/R.exe
```

Also the fourth question

```
Q4: What function executed the ransomware?
```

I went through the code and found out that

![16](/postImgs/letsdefend/RanDev/16.png)

this execute the file, so answer is 

```
Q4 Answer : exec();
```

Let's head to the fifth question and see what we need there.

```
Q5: The Ransomware contain a fake key to encrypt the files?
```

I went through the pc but couldn't find anything. so let's see the hint

```
Q5 Hint: Some reverse required here.
```

Hmm reverse required it seems we need to make reverse engineering on the Ransomware to get the answer of the question so let's open the "R.exe" on IDA pro or any disassember.

![17](/postImgs/letsdefend/RanDev/17.png)

ohh some interesting stuffs. let's investigate it and see what we can extract from it.
and we need the fake key so let's make this assembly more clear by convert into pesudo code

![18](/postImgs/letsdefend/RanDev/18.png)

now it's clear for us to get the key.

![19](/postImgs/letsdefend/RanDev/19.png)

```
Q5 Answer: KRKTCUCXIZJESUSVNBBFCMDUIZKWOPJ5
```

and about the sixth question.
```
Q6: What is the extension of the ransomware?
```
we need to find the extension of the encrypted files.
and finally about looking for a good amount of time I reached the extension which it was inside a fucntion called "xor_encryption".

![21](/postImgs/letsdefend/RanDev/21.png)

Which if you see the image below has the extension that beeing added

![20](/postImgs/letsdefend/RanDev/20.png)


So the answer of the sixth question is
```
Q6 Answer: .D7k
```

and the 7th question is 

```
Q7: What is the Correct KEY that encrypted the data?
```

as we can got the previous key was fake so let's check the "xor_encryption" function again and try to get the correct key.

![22](/postImgs/letsdefend/RanDev/22.png)

I noticed in this part that it xor the data with key "0x2C" so let's try to submit it.
well it's correct key
```
Q7 Answer: 0x2C
```

and the last question is
```
Q8: After getting the correct key can you decrypt Tasks.txt and tell me how many tasks are there?
```

now we have everything all we need is to create a script to xor the data with key "0x2C"
```python
key = 0x2C

with open('Tasks.txt', 'rb') as infile, open('Tasks.txt', 'wb') as outfile:
    contents = infile.read()
    decrypt = bytes([byte ^ key for byte in contents])
    outfile.write(decrypt)
```

![23](/postImgs/letsdefend/RanDev/23.png)

seems the answer is
```
Q8: 17
```

> hope you enjoyed and thanks Thank you 