+++
author = "MMOX"
title = "Wicsme 2020 Writeups"
date = "2019-11-20"
description = "Digital Forensic Challenges Writeups and one binary Exploition Challenge"
tags = [
    "CTF",
    "Writeups",
    "Digital Forensics",
]
categories = [
    "Writeups",
    "CTF",
	"Digital Forensics",
]

favorite= true
show_comments= true
showToc= true
Tocopen= true
+++

![image](/postImgs/wismie.jpg)
# Digital Forensics
 
## Fe01 
 
It was an easy one there was a .rtf file when i opened it using ("libre office Writer") i found: 


![1](https://user-images.githubusercontent.com/33530187/99195681-2c11ce80-2755-11eb-9103-01f23bf3878b.png)


by clicking (Ctr+A) I selected all the right clicked to choose paragraph - Text Body

![2](https://user-images.githubusercontent.com/33530187/99195858-6039bf00-2756-11eb-9cad-21085cd6eca9.png)

the flag appered
![flag](https://user-images.githubusercontent.com/33530187/99195866-6e87db00-2756-11eb-8217-1e0b8d33ae59.png)

the flag was : **n𝑖𝐶𝑒𝐴𝑛𝐷𝐸𝑎𝑠𝑦10018**

## Fe02

it was a PDF File with a black mark that hide some parts of the text, I Opend it using ("Atril Document Viewer") 
And that what appered: 

![1](https://user-images.githubusercontent.com/33530187/99196046-d854b480-2757-11eb-9ae6-3b515dd35fd8.png)

i was going to reverse the pdf but i noticed Some thing when i highlight a text it appers 

![2](https://user-images.githubusercontent.com/33530187/99196086-18b43280-2758-11eb-9e4b-730207412d80.png)

so I easily selected the hole file and found the flag:
![flag](https://user-images.githubusercontent.com/33530187/99196138-616beb80-2758-11eb-8283-08642fd67fbf.png)

And the flag was : **n1CeReDaCTION-sureLYNot911081**


## Fe03

when i unzipped the challenge there was a flag.zip password protected
so I knew it's a simple password cracking Challenge 
using zip2john I got the hash  

![1](https://user-images.githubusercontent.com/33530187/99196407-35ea0080-275a-11eb-90b9-10b8318d5f7c.png)

Then by using Rockyou.txt to brute force The password it succeeded 
![johend](https://user-images.githubusercontent.com/33530187/99196524-d9d3ac00-275a-11eb-8496-6344bc0cc74b.png)


and the password was :
	**q1w2e3r4t5y6**
by using this passsowrd i was able to extract the text file :
![flag](https://user-images.githubusercontent.com/33530187/99196624-988fcc00-275b-11eb-9d4b-25effcf52bb9.png)


the flag was  : **CraCKInGJ0b-67189**


## Fe04

it was an .log file So i tried the first thing I could think of 

using the command strings with grep flag 

so I did that 

    strings access.log |grep flag


and that was it the flag appeared  

![flag](https://user-images.githubusercontent.com/33530187/99196830-c1fd2780-275c-11eb-8e9f-bcc4aaa416bf.png)

the Flag was: **nicESearChIng01812** 


## FM01

It was a weird file i used file to idintfy it but it showed Data file 

![1](https://user-images.githubusercontent.com/33530187/99196983-7a2ad000-275d-11eb-80bf-e3c125484c95.png)

so i opend it on hex editor to see the header 

![2](https://user-images.githubusercontent.com/33530187/99197077-2c629780-275e-11eb-9e39-5e9bb123adb8.png)


the Hex was similar to a binary file but the header was wrong
So i fixed it by adding the right header

![the fixed header](https://user-images.githubusercontent.com/33530187/99197901-51a5d480-2763-11eb-997e-f2cfac8f87df.png)

and by using 

 

    chmod +x file| ./file




![flag](https://user-images.githubusercontent.com/33530187/99197986-bbbe7980-2763-11eb-858f-6b6b2d070dee.png)











# Binary-Exploit-Challenges 


## Be01

the first thing i tried is running the program 
it asked for a password so i didn't know what to do but using ("strings") as usual

![1](https://user-images.githubusercontent.com/33530187/99198574-9469ab80-2767-11eb-8999-9fff5b32f9b9.png)




i saw a wired text : **this_isNOT-a_PasswORD-ToGuess-Easily**
so i tried using it as the password and the flag poped 

![flag](https://user-images.githubusercontent.com/33530187/99198637-f1fdf800-2767-11eb-9f63-7745eddbf05e.png)


and the Flag was : **sImpLEASCiiSTriNGS-32910**



 
# [Web-Writeups](https://abdelhameedghazy.medium.com/wics-and-sans-bootup-ctf-web-challenges-writeup-1eaef85eb36a)

