+++
author = ["MMOX ","xElessaway"]
title = "MemLabs Writeup - Lab 1 (Beginner's Luck - Easy) "
date = "2021-03-01"
description = "Digital Forensic Memory Dump challenges Writeups "
tags = [
    "MemLabs",
    "Writeups",
    "Digital Forensics",
]
categories = [
    "Writeups",
    "DFIR",
	"Memory",
	"Digital Forensics",
]

favorite= true
show_comments= true
showToc= true
Tocopen= false
+++
![MemLabs-logo](/postImgs/MemLabs-logo.png)

|Lab   |   Challenge link   | difficulty| Writeup link|
|------|--------------------|------|-------------------------|
|Lab 1 | [Beginner's Luck](https://mega.nz/#!6l4BhKIb!l8ATZoliB_ULlvlkESwkPiXAETJEF7p91Gf9CWuQI70) | Easy |[Lab 1 ](https://www.mmox.me/posts/writeups/memlabs-lab1/)|
|Lab 2 | [A New World ](https://mega.nz/#!ChoDHaja!1XvuQd49c7-7kgJvPXIEAst-NXi8L3ggwienE1uoZTk)   | Easy |[Lab 2 ](https://www.mmox.me/posts/writeups/memlabs-lab2/)|
|Lab 3 | [The Evil's Den](https://mega.nz/#!2ohlTAzL!1T5iGzhUWdn88zS1yrDJA06yUouZxC-VstzXFSRuzVg) |Easy - Medium|[Lab 3 ](https://www.mmox.me/posts/writeups/memlabs-lab3/)|
|Lab 4 | [Obsession](https://mega.nz/#!Tx41jC5K!ifdu9DUair0sHncj5QWImJovfxixcAY-gt72mCXmYrE)      |Medium|[Lab 4 ](https://www.mmox.me/posts/writeups/memlabs-lab4/)|
|Lab 5 | [Black Tuesday](https://mega.nz/#!Ps5ViIqZ!UQtKmUuKUcqqtt6elP_9OJtnAbpwwMD7lVKN1iWGoec)   | Medium - Hard |[Lab 5 ](https://www.mmox.me/posts/writeups/memlabs-lab5/)|
|Lab 6 | [The Reckoning](https://mega.nz/#!C0pjUKxI!LnedePAfsJvFgD-Uaa4-f1Tu0kl5bFDzW6Mn2Ng6pnM)   |Hard|[Lab 6 ](https://www.mmox.me/posts/writeups/memlabs-lab6/)|

# Challenge description
	
	My sister's computer crashed. We were very fortunate to recover this memory dump. 
	Your job is get all her important files from the system. From what we remember,
	we suddenly saw a black window pop up with some thing being executed. When the 
	crash happened, she was trying to draw something. Thats all we remember from 
	the time of crash.

* Note: This challenge is composed of 3 flags.

# Writeup

## Stage 1
our first Step will be checking the image info to know which profile will be used in the analysis 

	.\volatility.exe -f .\MemoryDump_Lab1.raw imageinfo

![lab1-1](/postImgs/lab1/lab1-1.jpg)

As we see it "Win7SP1x64"

So let’s start check the process and see if there are anything suspicious 

	.\volatility.exe -f .\MemoryDump_Lab1.raw --profile=Win7SP1x64 pslist

![lab1-2](/postImgs/lab1/lab1-2.jpg)

So we found cmd.exe that was running so we scanned it 

	.\volatility.exe -f .\MemoryDump_Lab1.raw --profile=Win7SP1x64 cmdscan
	
![lab1-3](/postImgs/lab1/lab1-3.jpg)

we found that he typed something interesting in cmd called (“St4G3$1”)
So lets check the consoles

	.\volatility.exe -f .\MemoryDump_Lab1.raw --profile=Win7SP1x64 consoles


![lab1-4](/postImgs/lab1/lab1-4.jpg)

there was base 64 Text after decoding we got the first flag
	
	flag{th1s_1s_th3_1st_st4g3!!}

## Stage 2

for the next flag We checked process again and found that there is process called (“mspaint.exe”) so let’s dump it

	.\volatility.exe -f .\MemoryDump_Lab1.raw --profile=Win7SP1x64 memdump -p 2424 -D output
	
![lab1-5](/postImgs/lab1/lab1-5.jpg)

we changed the extension of the dump from .dmp to .data to be raw image data so we can open it using GIMP

![lab1-6](/postImgs/lab1/lab1-6.jpg)

So it’s a not making any sense so we tried to change the heights and widths 

![lab1-7](/postImgs/lab1/lab1-7.jpg)

We got this so let’s reverse it and see what it says

![lab1-8](/postImgs/lab1/lab1-8.jpg)

and we got the 2nd flag
	flag{G00d_BoY_good_girL}

## Stage 3

while we were checking the processes we noticed that winrar was running 

so we did a file scan

	.\volatility.exe -f .\MemoryDump_Lab1.raw --profile=Win7SP1x64 filescan

![lab1-9](/postImgs/lab1/lab1-9.jpg)

Okay that’s a lot of files so Winrar uses ( .zip , .rar ) so let’s grep them

![lab1-10](/postImgs/lab1/lab1-10.jpg)

there was a file called important so we extract it 

	.\volatility.exe -f .\MemoryDump_Lab1.raw --profile=Win7SP1x64 dumpfiles -Q 0x000000003fa3ebc0 -D output

![lab1-11](/postImgs/lab1/lab1-11.jpg)

![lab1-12](/postImgs/lab1/lab1-12 .jpg)

we got the rar but it's password protected 
to get the password we have to get the NTLM hash
by using hashdump 

	.\volatility.exe -f .\MemoryDump_Lab1.raw --profile=Win7SP1x64 hashdump

![lab1-13](/postImgs/lab1/lab1-13.jpg)

we got the password 

	F4FF64C8BAAC57D22F22EDC681055BA6
	
the 3rd flag is: 

	flag{w3ll_3rd_stage_was_easy}