+++
author = ["MMOX ","xElessaway"]
title = "MemLabs Writeup - Lab 2 (A New World - Easy) "
date = "2021-03-01"
description = "Digital Forensic Memory Dump challenges Writeups "
tags = [
    "MemLabs",
    "Writeups",
    "Digital Forensics",
]
categories = [
    "Writeups",
    "DFIR",
	"Memory",
	"Digital Forensics",
]

favorite= true
show_comments= true
showToc= true
Tocopen= false
+++
![MemLabs-logo](/postImgs/MemLabs-logo.png)


|Lab   |   Challenge link   | difficulty| Writeup link|
|------|--------------------|------|-------------------------|
|Lab 1 | [Beginner's Luck](https://mega.nz/#!6l4BhKIb!l8ATZoliB_ULlvlkESwkPiXAETJEF7p91Gf9CWuQI70) | Easy |[Lab 1 ](https://www.mmox.me/posts/writeups/memlabs-lab1/)|
|Lab 2 | [A New World ](https://mega.nz/#!ChoDHaja!1XvuQd49c7-7kgJvPXIEAst-NXi8L3ggwienE1uoZTk)   | Easy |[Lab 2 ](https://www.mmox.me/posts/writeups/memlabs-lab2/)|
|Lab 3 | [The Evil's Den](https://mega.nz/#!2ohlTAzL!1T5iGzhUWdn88zS1yrDJA06yUouZxC-VstzXFSRuzVg) |Easy - Medium|[Lab 3 ](https://www.mmox.me/posts/writeups/memlabs-lab3/)|
|Lab 4 | [Obsession](https://mega.nz/#!Tx41jC5K!ifdu9DUair0sHncj5QWImJovfxixcAY-gt72mCXmYrE)      |Medium|[Lab 4 ](https://www.mmox.me/posts/writeups/memlabs-lab4/)|
|Lab 5 | [Black Tuesday](https://mega.nz/#!Ps5ViIqZ!UQtKmUuKUcqqtt6elP_9OJtnAbpwwMD7lVKN1iWGoec)   | Medium - Hard |[Lab 5 ](https://www.mmox.me/posts/writeups/memlabs-lab5/)|
|Lab 6 | [The Reckoning](https://mega.nz/#!C0pjUKxI!LnedePAfsJvFgD-Uaa4-f1Tu0kl5bFDzW6Mn2Ng6pnM)   |Hard|[Lab 6 ](https://www.mmox.me/posts/writeups/memlabs-lab6/)|

# Challenge description

	One of the clients of our company, lost the access to his system due to an unknown error. 
	He is supposedly a very popular "environmental" activist. As a part of the investigation, 
	he told us that his go to applications are browsers, his password managers etc. We hope
	that you can dig into this memory dump and find his important stuff and give it back to us.

* Note: This challenge is composed of 3 flags.

# Writeup
## Stage 2 

As always we will use imageinfo to know the profile
 
	.\volatility.exe -f .\MemoryDump_Lab2.raw imageinfo

let’s check process 

	.\volatility.exe -f .\MemoryDump_Lab2.raw --profile=Win7SP1x64 pslist

![lab2-1](/postImgs/lab2/lab2-1.jpg)

Hmmm there is a process called (“KeePass.exe”) so after googling about it,
It’s An application to save usernames and passwords and use (“.kdbx”)
So let’s do file scan and grep all files that has .kdbx

	.\volatility.exe -f .\MemoryDump_Lab2.raw --profile=Win7SP1x64 filescan | grep .kdbx

![lab2-2](/postImgs/lab2/lab2-2.jpg)

So now this is interesting (“Hidden.kdbx”)
Lets extract this
	
	.\volatility.exe -f .\MemoryDump_Lab2.raw --profile=Win7SP1x64 dumpfiles -Q 0x000000003fb112a0 -D output

![lab2-3](/postImgs/lab2/lab2-3.png)


It needs password so let’s try to grep Password in filescan

	.\volatility.exe -f .\MemoryDump_Lab2.raw --profile=Win7SP1x64 filescan | grep -i Password

![lab2-4](/postImgs/lab2/lab2-4.jpg)

	.\volatility.exe -f .\MemoryDump_Lab2.raw --profile=Win7SP1x64 dumpfiles -Q 0x000000003fce1c70 -D output



![lab2-5](/postImgs/lab2/lab2-5.png)

and here is the password: 

	P4SSw0rd_123 

![lab2-6](/postImgs/lab2/lab2-6.jpg)

And here is the flag: 
	flag{w0w_th1s_1s_Th3_SeC0nD_ST4g3_!!}
But we noticed that this is the 2nd stage flag lol :D
So let’s search for the first stage flag.

## Stage 1 
Lets check the history

	.\volatility.exe -f .\MemoryDump_Lab2.raw --profile=Win7SP1x64 envars

![lab2-7](/postImgs/lab2/lab2-7.png)
There is a base 64 encoded string 

	ZmxhZ3t3M2xjMG0zX1QwXyRUNGczXyFfT2ZfTDRCXzJ9

after decoding it we got the flag:

	flag{w3lc0m3_T0_$T4g3_!_Of_L4B_2}

## Stage 3 

we are going to extract the chrome history to check it 
	
	./volatility.exe -f MemoryDump_Lab2.raw --profile=Win7SP1x64 filescan |grep '\\Chrome\\User Data\\Default\\History'

![lab2-8](/postImgs/lab2/lab2-8.png)


we are going to dump it 

	./volatility.exe -f MemoryDump_Lab2.raw --profile=Win7SP1x64 dumpfiles -Q 0x000000003fcfb1d0 -D .

then using "SQLiteDatabaseBrowser" to check it

![lab2-9](/postImgs/lab2/lab2-9.png)

while checking the url table there was a mega link

	https://mega.nz/#F!TrgSQQTS!H0ZrUzF0B-ZKNM3y9E76lg

![lab2-10](/postImgs/lab2/lab2-10.png)

when i opened it there was a file named "Important.zip"


so i downloaded it and tried to extract the image but there is a note that says

![lab2-11](/postImgs/lab2/lab2-11.png)

	Password is SHA1(stage-3-FLAG) from Lab-1. Password is in lowercase.
	
as we already solved the first challenge it was easy for us to get the sha1 

and the password was 

	6045dd90029719a039fd2d2ebcca718439dd100a

in the extraxted image there was the third flag 

![lab2-flag3](/postImgs/lab2/flag3.png)

	 flag{oK_So_Now_St4g3_3_is_DoNE!!} 
