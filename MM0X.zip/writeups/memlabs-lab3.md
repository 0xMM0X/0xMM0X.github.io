+++
author = ["MMOX ","xElessaway"]
title = "MemLabs Writeup - Lab 3 (The Evil's Den - Easy Medium) "
date = "2021-03-01"
description = "Digital Forensic Memory Dump challenges Writeups "
tags = [
    "MemLabs",
    "Writeups",
    "Digital Forensics",
]
categories = [
    "Writeups",
    "DFIR",
	"Memory",
	"Digital Forensics",
]

favorite= true
show_comments= true
showToc= true
Tocopen= false
+++
![MemLabs-logo](/postImgs/MemLabs-logo.png)


|Lab   |   Challenge link   | difficulty| Writeup link|
|------|--------------------|------|-------------------------|
|Lab 1 | [Beginner's Luck](https://mega.nz/#!6l4BhKIb!l8ATZoliB_ULlvlkESwkPiXAETJEF7p91Gf9CWuQI70) | Easy |[Lab 1 ](https://www.mmox.me/posts/writeups/memlabs-lab1/)|
|Lab 2 | [A New World ](https://mega.nz/#!ChoDHaja!1XvuQd49c7-7kgJvPXIEAst-NXi8L3ggwienE1uoZTk)   | Easy |[Lab 2 ](https://www.mmox.me/posts/writeups/memlabs-lab2/)|
|Lab 3 | [The Evil's Den](https://mega.nz/#!2ohlTAzL!1T5iGzhUWdn88zS1yrDJA06yUouZxC-VstzXFSRuzVg) |Easy - Medium|[Lab 3 ](https://www.mmox.me/posts/writeups/memlabs-lab3/)|
|Lab 4 | [Obsession](https://mega.nz/#!Tx41jC5K!ifdu9DUair0sHncj5QWImJovfxixcAY-gt72mCXmYrE)      |Medium|[Lab 4 ](https://www.mmox.me/posts/writeups/memlabs-lab4/)|
|Lab 5 | [Black Tuesday](https://mega.nz/#!Ps5ViIqZ!UQtKmUuKUcqqtt6elP_9OJtnAbpwwMD7lVKN1iWGoec)   | Medium - Hard |[Lab 5 ](https://www.mmox.me/posts/writeups/memlabs-lab5/)|
|Lab 6 | [The Reckoning](https://mega.nz/#!C0pjUKxI!LnedePAfsJvFgD-Uaa4-f1Tu0kl5bFDzW6Mn2Ng6pnM)   |Hard|[Lab 6 ](https://www.mmox.me/posts/writeups/memlabs-lab6/)|

# Challenge description
	A malicious script encrypted a very secret piece of information I had on my system. 
	Can you recover the information for me please?

* This challenge is composed of only 1 flag. The flag split into 2 parts.

* You'll need the first half of the flag to get the second.

* You will need this additional tool to solve the challenge
	
	
	sudo apt install steghide

* The flag format for this lab is: inctf{s0me_l33t_Str1ng}


# Writeup

## Part 1

as always we will use image info to get the profile

	./volatility.exe -f MemoryDump_Lab3.raw imageinfo

![lab3-1](/postImgs/lab3/1.png)

so this time it's "Win7SP1x86"

by doing cmdline 

	./volatility.exe -f MemoryDump_Lab3.raw --profile=Win7SP1x86 cmdline
	
![lab3-2](/postImgs/lab3/2.png)

we found 2 files "evelscript.py" and "vip.txt"
so we will do file scan and grep the 2 files for extraction 

	./volatility.exe -f MemoryDump_Lab3.raw --profile=Win7SP1x86 filescan |grep "evilscript.py"
	./volatility.exe -f MemoryDump_Lab3.raw --profile=Win7SP1x86 filescan |grep "vip.txt"
	
![lab3-3](/postImgs/lab3/3.png)

after dumping them using dumpfiles with the offset
	 
	 ./volatility.exe -f MemoryDump_Lab3.raw --profile=Win7SP1x86 dumpfiles -Q 0x000000003e727e50 -D .
	 ./volatility.exe -f MemoryDump_Lab3.raw --profile=Win7SP1x86 dumpfiles -Q 0x000000003de1b5f0 -D .
the "vip" text was :
	
	am1gd2V4M20wXGs3b2U=
	
the script was easy to analys:
 
	import sys
	import string

	def xor(s):

		a = ''.join(chr(ord(i)^3) for i in s)
		return a


	def encoder(x):
		
		return x.encode("base64")


	if __name__ == "__main__":

		f = open("C:\\Users\\hello\\Desktop\\vip.txt", "w")

		arr = sys.argv[1]

		arr = encoder(xor(arr))

		f.write(arr)

		f.close()

1. take input
2. xor it with key 3 
3. encoded to base64
4. write it in the vip file 

so we will do the oppsite
we will take the text from the vip file
and by using [CyberChef](https://gchq.github.io/CyberChef/#recipe=From_Base64('A-Za-z0-9%2B/%3D',true)XOR(%7B'option':'Hex','string':'3'%7D,'Standard',false)&input=YW0xZ2QyVjRNMjB3WEdzM2IyVT0) we will get the first half

![lab3-4](/postImgs/lab3/4.png)

now we have the first part 

	inctf{0n3_h4lf

## Part 2 

he provided us with a tool to use with is "steghide"
as we know it's stegnography tool so let's serch again for jpg ,jpeg and png 

	./volatility.exe -f MemoryDump_Lab3.raw --profile=Win7SP1x86 filescan |grep ".jpg"
	./volatility.exe -f MemoryDump_Lab3.raw --profile=Win7SP1x86 filescan |grep ".jpeg"  

![lab3-5](/postImgs/lab3/5.png)

by getting the jpeg files there was only 1 file called "suspision1.jpeg"
let's dump it and as I use windows I had to rename it 

	./volatility.exe -f MemoryDump_Lab3.raw --profile=Win7SP1x86 dumpfiles -Q 0x0000000004f34148 -D .

![suspision1.jpeg](/postImgs/lab3/suspision1.jpeg)

by using steghide and assuming the first half is the passphrase we goth the second half easly
	
	steghide extract -sf suspision1.jpeg -p inctf{0n3_h4lf
	cat secret\ text

![lab3-6](/postImgs/lab3/6.png)
	
so the flag was 

	inctf{0n3_h4lf_1s_n0t_3n0ugh}