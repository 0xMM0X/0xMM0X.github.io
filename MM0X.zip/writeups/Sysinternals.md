+++
author = "MMOX"
title = "Cyber Defenders - Sysinternals"
date = "2023-04-15"
description = "A Disk Image forensics. "

tags = [
    "cyberdefenders",
    "Writeups",
    "Digital Forensics",
]
categories = [
    "Writeups",
    "DFIR",
	"Memory",
	"Disk",
	"Digital Forensics",
]

favorite= true
show_comments= true
showToc= true
Tocopen= false
Draft= false
+++

![logo](/postImgs/cyberdefender/SysInternals/logo.png)


# Description
	
	A user thought they were downloading the SysInternals tool suite and attempted to open it, but the tools did not launch and became inaccessible. Since then, the user has observed that their system has gradually slowed down and become less responsive.

## Challenge Link :

	https://cyberdefenders.org/blueteam-ctf-challenges/55

- Supportive Tools:

	* [Registry Explorer](https://ericzimmerman.github.io/#!index.md)
	* [Event Log Explorer](https://eventlogxp.com/)
	* [AppCompatCachParser](https://www.sans.org/tools/appcompatcacheparser/)
	* [VirsuTotal](https://www.virustotal.com/)
	* [Web Cache View](https://www.nirsoft.net/utils/ie_cache_viewer.html)
	* [FTK Imager](https://www.exterro.com/ftk-imager#:~:text=FTK%C2%AE%20Imager%20is%20a,(FTK%C2%AE)%20is%20warranted.)
	* [Autopsy](https://www.autopsy.com/)
	
# Writeup

## Q1 
	
	1: What was the malicious executable file name that the user downloaded?

this one was an easy Question all u needed to do is to search for the downloaded executable which was the only progroam in the public download folder 

![1](/postImgs/cyberdefender/SysInternals/1.png)

> Answer : SysInternals.exe

## Q2

	When was the last time the malicious executable file was modified? 12-hour format

once you identfied the file in Q1 it's easy to get the last modified date once you extract the exe all u need to do is to check the properites 
you will find the modification time but As my time zone is UTC +2 so i needed to substract 2 hours from the time to get the correct answer

![2](/postImgs/cyberdefender/SysInternals/2.png)

>Answer : 11/15/2022 09:18:51 PM


## Q3
	
	What is the SHA1 hash value of the malware?

I stucked in this question for a while then i decided to check the free hint 

![3](/postImgs/cyberdefender/SysInternals/3.png)

So i started there 
Using the Eric Zimmerman Great tools "AmcacheParser" to parse the data  we found 

```powershell
.\AmcacheParser.exe -f .\Amcache.hve --csv out
```
when i checked the output theree was 2 files that has data by cheacking the `20230415203241_Amcache_UnassociatedFileEntries.csv` i found the hash 

![4](/postImgs/cyberdefender/SysInternals/4.png)

> Answer : fa1002b02fc5551e075ec44bb4ff9cc13d563dcf

## Q4
	
	What is the malware's family?

once I got the hash i used viurstotal to identfy the  malware family [Viurstotal](https://www.virustotal.com/gui/file/72e6d1728a546c2f3ee32c063ed09fa6ba8c46ac33b0dd2e354087c1ad26ef48)


![5](/postImgs/cyberdefender/SysInternals/5.png)

## Q5
	
	What is the first mapped domain's Fully Qualified Domain Name (FQDN)?

also from the same [Viurstotal](https://www.virustotal.com/gui/file/72e6d1728a546c2f3ee32c063ed09fa6ba8c46ac33b0dd2e354087c1ad26ef48) Page in the relastion tab i found the URL which has most detection than the others

> Answer : www.malware430.com

## Q6
	
	The mapped domain is linked to an IP address. What is that IP address?

I couldn't find this IP in virus total and after a while i unlocked the hint which guided me to the powershell history once i know that i went there right away to
get the answer

![6](/postImgs/cyberdefender/SysInternals/6.png)

> Answer : 192.168.15.10

## Q7

	What is the name of the executable dropped by the first-stage executable?

I Couldn't find the name in vuirstotal eather so i did a quick analysis with my ultimte tool `strings` over the sample i found the exe name 

```bash
strings SysInternals.exe |grep exe
```

![7](/postImgs/cyberdefender/SysInternals/7.png)

> Answer : vmtoolsIO.exe
## Q8

	What is the name of the service installed by 2nd stage executable?

that was a quick one from the same output as the last i found the service that the vmtoolsIO.exe starting which is `VMwareIOHelperService`


> Answer : VMwareIOHelperService

## Q9 
	
	What is the extension of files deleted by the 2nd stage executable?

That was a tricky one it took me a while to solve it i tried to get it from online sandbox but couldn't so i did it into my virtual lab 
using vmware i executed the sample and with sysmon to see file modifications as i was dump to not enable the filedeletation rule so i had to be creative
so i checked for file created so finally i go the answer


![8](/postImgs/cyberdefender/SysInternals/8.png)

> Answer : pf


![9](/postImgs/cyberdefender/SysInternals/9.png)
