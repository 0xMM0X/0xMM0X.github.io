+++
author = ["MMOX ","xElessaway"]
title = "MemLabs Writeup - Lab 5 (Black Tuesday - Medium Hard) "
date = "2021-03-01"
description = "Digital Forensic Memory Dump challenges Writeups "
tags = [
    "MemLabs",
    "Writeups",
    "Digital Forensics",
]
categories = [
    "Writeups",
    "DFIR",
	"Memory",
	"Digital Forensics",
]

favorite= true
show_comments= true
showToc= true
Tocopen= false
+++
![MemLabs-logo](/postImgs/MemLabs-logo.png)


|Lab   |   Challenge link   | difficulty| Writeup link|
|------|--------------------|------|-------------------------|
|Lab 1 | [Beginner's Luck](https://mega.nz/#!6l4BhKIb!l8ATZoliB_ULlvlkESwkPiXAETJEF7p91Gf9CWuQI70) | Easy |[Lab 1 ](https://www.mmox.me/posts/writeups/memlabs-lab1/)|
|Lab 2 | [A New World ](https://mega.nz/#!ChoDHaja!1XvuQd49c7-7kgJvPXIEAst-NXi8L3ggwienE1uoZTk)   | Easy |[Lab 2 ](https://www.mmox.me/posts/writeups/memlabs-lab2/)|
|Lab 3 | [The Evil's Den](https://mega.nz/#!2ohlTAzL!1T5iGzhUWdn88zS1yrDJA06yUouZxC-VstzXFSRuzVg) |Easy - Medium|[Lab 3 ](https://www.mmox.me/posts/writeups/memlabs-lab3/)|
|Lab 4 | [Obsession](https://mega.nz/#!Tx41jC5K!ifdu9DUair0sHncj5QWImJovfxixcAY-gt72mCXmYrE)      |Medium|[Lab 4 ](https://www.mmox.me/posts/writeups/memlabs-lab4/)|
|Lab 5 | [Black Tuesday](https://mega.nz/#!Ps5ViIqZ!UQtKmUuKUcqqtt6elP_9OJtnAbpwwMD7lVKN1iWGoec)   | Medium - Hard |[Lab 5 ](https://www.mmox.me/posts/writeups/memlabs-lab5/)|
|Lab 6 | [The Reckoning](https://mega.nz/#!C0pjUKxI!LnedePAfsJvFgD-Uaa4-f1Tu0kl5bFDzW6Mn2Ng6pnM)   |Hard|[Lab 6 ](https://www.mmox.me/posts/writeups/memlabs-lab6/)|

# Challenge description

	We received this memory dump from our client recently. Someone accessed his system when he was not
	there and he found some rather strange files being accessed. Find those files and they might be useful.
	I quote his exact statement,
	"The names were not readable. They were composed of alphabets and numbers but 
	I wasn't able to make out what exactly it was."
	Also, he noticed his most loved application that he always used crashed every time he ran it. Was it a virus?

* Note-1: This challenge is composed of 3 flags. If you think 2nd flag is the end, it isn't!! :P

* Note-2: There was a small mistake when making this challenge. If you find any string which has the string "L4B_3_D0n3!!" in it, please change it to "L4B_5_D0n3!!" and then proceed.

* Note-3: You'll get the stage 2 flag only when you have the stage 1 flag.

# Writeup

## Stage 1 
first cheching for the profille 

	./volatility.exe -f MemoryDump_Lab5.raw imageinfo
	
![lab5-1](/postImgs/lab5/1.png)

so it's "Win7SP1x64 " like most of the challenges
when he tries to open the file the device crashed so let's see the iehistory

	./volatility.exe -f MemoryDump_Lab5.raw --profile=Win7SP1x64 iehistory
	
![lab5-2](/postImgs/lab5/2.png)

the first thing that poped was bmp with a base64 text 

	ZmxhZ3shIV93M0xMX2QwbjNfU3Q0ZzMtMV8wZl9MNEJfNV9EMG4zXyEhfQ
	
so let's decode it and we got the first flag

	flag{!!_w3LL_d0n3_St4g3-1_0f_L4B_5_D0n3_!!}
	
## Stage 2

now let's check the pslist

	./volatility.exe -f MemoryDump_Lab5.raw --profile=Win7SP1x64 pslist           

there was 2 process that got my attention WinRAR and process called NOTEPAD.EXE

![lab5-3](/postImgs/lab5/3.png)

so let's check the files for .rar

	./volatility.exe -f MemoryDump_Lab5.raw --profile=Win7SP1x64 filescan |grep .rar      

![lab5-4](/postImgs/lab5/4.png)

i dumped it
	
	./volatility.exe -f MemoryDump_Lab5.raw --profile=Win7SP1x64 dumpfiles -Q 0x000000003eed56f0 -D .
	
then extracted it but it was password protected but as note 3 said 
i must get the fist flag to get the seconed so i usedthe flag as password to extract the image 

![flag2](/postImgs/lab5/flag2.png)

and i got the 2nd flag

	flag{W1th_th1s_$taGe_2_1s_c0mPL3T3!!} 


## Stage 3

The picture said that lab 5 is finished but the note said there is 3 flags and I 
noticed a suspicious process called "NOTEPAD.EXE" so i will do psxview to get the pid 

	./volatility.exe -f MemoryDump_Lab5.raw --profile=Win7SP1x64 psxview


![lab5-5](/postImgs/lab5/5.png)

let's dump it
	
	./volatility.exe -f MemoryDump_Lab5.raw --profile=Win7SP1x64 procdump -p 2724 -D .
	
I opened with IDAPro64 for analysis 

![lab5-6](/postImgs/lab5/6.png)

and the flag was there 
	
	 bi0s{M3m_l4b5_OVeR_!}  
