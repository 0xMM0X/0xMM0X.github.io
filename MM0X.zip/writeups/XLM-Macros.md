+++
author = "MMOX "
title = "Cyber Defenders - XLM-Macros"
date = "2022-12-06"
description = "Digital Forensic Memory Dump challenge Writeup "
tags = [
    "cyberdefenders",
    "Writeups",
    "Digital Forensics",
	"Malware Analysis",
	"Macros"
]
categories = [
    "Writeups",
    "DFIR",
	"Malware Analysis",
	"Digital Forensics",
]

favorite= true
show_comments= true
showToc= true
Tocopen= false
+++

![logo](/postImgs/cyberdefender/XLM-Macros/logo1.png)


# Description
	
	Recently, we have seen a resurgence of Excel-based malicous office documents. Howerver, instead of using VBA-style macros, 
	they are using older style Excel 4 macros. This changes our approach to analyzing these documents, 
	requiring a slightly different set of tools. In this challenge, you'll get hands-on with two documents 
	that use Excel 4.0 macros to perform anti-analysis and download the next stage of the attack.

## Challenge Link :

	https://cyberdefenders.org/blueteam-ctf-challenges/55

- Supportive Tools:

	* [REMnux VM](https://remnux.org/)
	* [XLMDeobfuscator](https://github.com/DissectMalware/XLMMacroDeobfuscator)
	* [OLEDUMP with PLUGIN_BIFF](https://blog.didierstevens.com/2021/02/12/quickpost-oledump-py-plugin_biff-py-remove-sheet-protection-from-spreadsheets/)
	
# Writeup

## Q1 
	
	1: Sample1: What is the document decryption password?


I tried to crack it using john but it wasn't the correct way so I did some research and found a tool named [msoffcrypto-crack.py](https://github.com/DidierStevens/DidierStevensSuite/blob/master/msoffcrypto-crack.py)
	
	python3 msoffcrypto-crack.py sample1-fb5ed444ddc37d748639f624397cff2a.bin
	
![1](/postImgs/cyberdefender/XLM-Macros/1.png)

easy we got the password 

	
## Q2

	Sample1: This document contains six hidden sheets. What are their names? Provide the value of the one starting with S
	
for sure I am not going to open the file so I used olevba tool to get all the information I need
	
	olevba sample1-fb5ed444ddc37d748639f624397cff2a.bin >vba.txt 

checking the text file we got the sheetname but there was something wrong with the tool so i contacted the admin and found that the tools miss
the last char and it was 'p' so if you are here add the `p` to the sheetname you have or just use exiftoolto get the full sheet name correctly 
	
![2](/postImgs/cyberdefender/XLM-Macros/2.png)


## Q3
	
	Sample1: What URL is the malware using to download the next stage? Only include the second-level and top-level domain. For example, xyz.com.

I had some issues finding the url so I used the has over virus total and got the url from the behavior section , but when i went back to the description i noticed that i need the latest version of oletools so when I updated mine I found it easily

![3](/postImgs/cyberdefender/XLM-Macros/3.png)

## Q4
	
	Sample1: What malware family was this document attempting to drop?

That's an easy question using https://bazaar.abuse.ch/ to check the url and it was very clear 
	
![2](/postImgs/cyberdefender/XLM-Macros/4.png)

Now we have finished the first sample let's check the other

## Q5
	
	Sample2: This document has a very hidden sheet. What is the name of this sheet?

using the same method i used in the 2nd question i got the sheet name 

![2](/postImgs/cyberdefender/XLM-Macros/5.png)


## Q6
	
	Sample2: This document uses reg.exe. What registry key is it checking?


Using xlmdeobfuscator tool

	xlmdeobfuscator -f sample2-b5d469a07709b5ca6fee934b1e5e8e38.bin

we got the path of the key 

![2](/postImgs/cyberdefender/XLM-Macros/6.png)

using some searching we got the key name as the tool is erroring for me 

## Q7

	Sample2: From the use of reg.exe, what value of the assessed key indicates a sandbox environment?
by cheking `IF(ISNUMBER*`  function we found the value it searchs for in decimal converting it to the hex format will give you the answer

## Q8

	Sample2: This document performs several additional anti-analysis checks. What Excel 4 macro function does it use?

most of the if condation checks with the same function i think it's the correct one 

## Q9 
	
	Sample2: This document checks for the name of the environment in which Excel is running. What value is it using to compare?

when i read the xlm deobfuscated data i noticed that it's checking for specific os and the os name was the answer

## Q10

	Sample2: What type of payload is downloaded?

there was a call for `rundll32.exe` and we all know what it's used for what type of files

## Q11 

	Sample2: What URL does the malware download the payload from?

it's very clear in the deobfuscated data and it was the only file being downloaded

## Q12 

	Sample2: What is the filename that the payload is saved as?


The next paramter passed to the function that has the url of the downloaded file 
	
## Q13

	Sample2: How is the payload executed? For example, mshta.exe
	
after the file being downloaded there is a call for a system32 file the answer is the exe name 
 	
## Q14 

	Sample2: What was the malware family?

using the file hash over virustotal it was reported malicous from 32 vedors only trend micro had the malware family name