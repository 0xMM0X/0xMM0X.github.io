+++
author = "MMOX "
title = "Let's Defend - LockBit"
date = "2023-04-13"
description = "Digital Forensic Memory Dump challenge Writeup "
tags = [
    "Lets defend",
    "Writeups",
    "Digital Forensics",
	"Memory",
	"Ransomware"
]
categories = [
    "Writeups",
    "DFIR",
	"Malware Analysis",
	"Digital Forensics",
]

favorite= true
show_comments= true
showToc= true
Tocopen= false
+++

![logo](/postImgs/letsdefend/lockbit/logo.png)

```
Description: You are a Digital Forensics and Incident Response (DFIR) analyst tasked with investigating a ransomware attack that has affected a company's system. The attack has resulted in file encryption, and the attackers are demanding payment for the decryption of the affected files. You have been given a memory dump of the affected system to analyze and provide answers to specific questions related to the attack.
```

```
Q1: Using a memory dump analysis, can you determine the date and time that the device was infected with the malware?
Q2: What is the name of the ransomware family responsible for the attack?
Q3: What file extension is appended to the encrypted files by the ransomware?
Q4: What is the TLSH (Trend Micro Locality Sensitive Hash) of the ransomware?
Q5: Which MITRE ATT&CK technique was used by the ransomware to perform privilege escalation?
Q6: What is the SHA256 hash of the ransom note dropped by the malware?(Not in the sample provided use your googling skills)
Q7: What is the name of the registry key edited by the ransomware during the attack to apply persistence on the infected system?
```

```
Tools Required
1- Volatility
2- Registry Viewer
3- VirusTotal
```

in this challenge I got a memory dump. 

![1](/postImgs/letsdefend/lockbit/1.png)

Now we will use "**Volatility2**" to investigate this dump and first thing we do is check the operating system.

```bash
python2 vol.py -f LockBit.vmem imageinfo
```

![2](/postImgs/letsdefend/lockbit/2.png)

so the profile we are gonna use on this dump is "**Win7SP1x64**" now let's check the process.

```bash
python2 vol.py -f LockBit.vmem pslist
```

![3](/postImgs/letsdefend/lockbit/3.png)

You will notice that there is a suspcious process called "**mal.exe**" so the answer for the first question is

```
Q1 Answer: 2023-04-13 10:06:45
```

Let's head to the second question which is asking about the family of that ransomware. let's dump this process

```bash
python2 vol.py -f LockBit.vmem --profile=Win7SP1x64 procdump -p 900 -D.
```

![4](/postImgs/letsdefend/lockbit/4.png)

now we got the ransomware so let's check the hint "**VirusTotal**".
Let's upload it on virustotal and check the behavior.

![5](/postImgs/letsdefend/lockbit/5.png)

well we got the answer for the second question which is
```
Q2 Answer: lockbit
```

Now let's head to the 3rd question which says the ransom encryptes file with a specific extenstion. so I need to scanfile system and findout any suspicious extension.

```
python2 vol.py -f LockBit.vmem --profile=Win7SP1x64 filescan > files.txt
```

![6](/postImgs/letsdefend/lockbit/6.png)

So, I didn't know how to find the extnesion but if you check the hint "** Look for files on the system that have been encrypted by the ransomware and note the file extension.**" so it will encrypt images of course. let's find any png image.

![7](/postImgs/letsdefend/lockbit/7.png)

Yes this is the key for the third question 
```
Q3 Answer: .lockbit
```
Let's head to the fourth question which says he want the "**TLSH of the ransomware**" we can find it on the details tab in virus total 

![8](/postImgs/letsdefend/lockbit/8.png)

so the answer is
```
Q4 Answer:   
T119E3163DB459E165C8CF04B57E2516BAD671F83C037989F3EBD38C299420EE86626B07
```

Let's head to the fifth question now which asks about "**mitre ATT&CK Teqnique that used in this ransom do to privellage esclation**" so let's check the VirusTotal if there is something interesting.

![9](/postImgs/letsdefend/lockbit/9.png)

and yes I found the answer for the question 5.

```
Q5 Answer: T1543
```

Let's head to the sixth question which is "**The Ransom drops a note to restore the files can you get the SHA256 of the note?**". I went through the analysis of the VirusTotal and found that the Ransom drop file called "**C:/Program Files/dotnet/Restore-My-Files.txt**"
![10](/postImgs/letsdefend/lockbit/10.png)

So, we got the answer now
```
Q6 Answer: 67c6784a5296658ac4d633f4e8c0914ecc783b1cf2f6431818c4e2f3cdcce91f
```

Let's head now to the seventh question which is "**What is the name of the registry key edited by the ransomware during the attack to apply persistence on the infected system?**" so I won't open registries and look everywhere I need to understand how bitlock uses registry first so I went to google.

![11](/postImgs/letsdefend/lockbit/11.png)

Now I know it's inside the RUN so let's dump the registry and check the key there.

```bash
python2 vol.py -f LockBit.vmem --profile=Win7SP1x64 dumpregistry -D reg
```

![12](/postImgs/letsdefend/lockbit/12.png)

The hint says "**Check ntuserdat**" so let's open it on any registry viewer and look for
```
HKEY_CURRENT_USER\SOFTWARE\MICROSOFT\WINDOWS\CURRENTVERSION\RUN
```

![13](/postImgs/letsdefend/lockbit/13.png)

now we got the answer for the seventh question which is 
```
Q7 Answer: XO1XADpO01
```
