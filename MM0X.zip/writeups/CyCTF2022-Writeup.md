+++
author = "MMOX"
title = "CyCTF 2022 Writeups"
date = "2022-12-01"
description = "Digital Forensic Challenges Writeups and one Mobile"
tags = [
    "CTF",
    "Writeups",
    "Digital Forensics",
]
categories = [
    "Writeups",
    "CTF",
	"Digital Forensics",
	"Mobile",
]

favorite= true
show_comments= true
showToc= true
Tocopen= true
+++

![image](/postImgs/Cyshiled.jpg)

|Challenge Name   |   Challenge link   | Type|
|-----------------|--------------------|------|
|Lazaretto ✔|[Download](https://drive.google.com/file/d/1TAnz8e8m6DTI6tYNjTQ5JHoxqUeaoCH1/view?usp=share_link)|Forensics|
|Hotel ✔|[Download](https://drive.google.com/file/d/1Utfg9XjEGtbQEBXll8tx7IeBi4v-DsAL/view?usp=share_link)|Forensics|
|Subscription|[Download](https://drive.google.com/file/d/1QAVSgAO8CUiILtxXH6xjUMvj58pDUmUz/view?usp=share_link)|Forensics|
|Geology|docker pull cyctf/geology|Forensics|
|imPOSTer ✔|[Download](https://drive.google.com/file/d/1dNwxTBsGv54uKi7bcEd82Xw_eOrNywu2/view?usp=share_link)|Forensics|
|Mach ✔|[Download](https://drive.google.com/file/d/1tVVEizsVIrqgI1neT95xdrdqBmFhgo1s/view?usp=share_link)|Mobile|

# Lazaretto

## Challege Description 

![image](/postImgs/CyCTF/1.png)

## Writeup

we were provided with an ad1 file using FTKimager we were able to open it and it had only windows event logs

![image](/postImgs/CyCTF/2.png)

So i just dumped the files and using the famous ericzimmerman tool [EvtxECmd](https://f001.backblazeb2.com/file/EricZimmermanTools/EvtxECmd.zip) i was able to pares the full events into a csv file using this command
``` powershell
 .\EvtxECmd.exe -d .\Logs\ --csv out
```
from the csv it was an easy analysis by just filtring the level of the event and the events that has an executables it was only one 
event so it was easy

now we have all the data we needed to but in the flag format 
first part was the signutre id which was in payloadData1 `Ransom:Win32/Blocker`
secound part was the file name which was in the ExecutableInfo `makepcfaster.exe`
and last the delivery ip which was in the same place as the seconed part `192.168.1.8`

putting it into the flag format and that was it we have the flag 
```
CyCTF{Ransom:Win32/Blocker:makepcfaster.exe:192.168.1.8}
```

# Hotel 

## Challenge description

![image](/postImgs/CyCTF/3.png)

![image](/postImgs/CyCTF/4.png)

![image](/postImgs/CyCTF/5.png)


## Writeup

this was supposed to be a warm up challenge as it said in the description but it didn't have any solves before the hints ware realease
once the hint 1 realease i knew for sure that it's in the `MFT` file 
so i started doing my Dump thig with strings to get the flag 

while greping `CyCTF` it has nothing so i knew that it must be encoded so I did something more idiotice i encoded the CyCTF{ part 
using [CyberChef](https://gchq.github.io/CyberChef/)

![image](/postImgs/CyCTF/6.png)

and now just by using the magic of strings i grep this part `Q3lDVEZ7` and got the flag

![image](/postImgs/CyCTF/7.png)


```
strings \$MFT |grep Q3lDVEZ7
```
using CyberChef i decodced the base and got the flag 


![image](/postImgs/CyCTF/8.png)


```
CyCTF{MFT_C4N_S70RE_S3NS1TIV3_1NF0RM4710N}
```

# imPOSTer

## Challege Description

![image](/postImgs/CyCTF/9.png)

## Writeup

This challenge was the one that i enjoyed the most in the CTF

we were provided by a ZIP file of an system files so i un zipped the file and start checking 

i went to User `74mo` Document and found an outlook data folder so i checked it which has pst file 
so using [OST-viewer](https://www.systoolsgroup.com/ost-viewer.html) i opend the pst file 
it had some mails from 74mo to some developer about website then 74mo asked for his database to be encrypted 
the developer sent him the way he did the encryption and the dummy key and that was our starting point 

![image](/postImgs/CyCTF/10.png)

the challenge name ha POST in it and the email confirm it was a site dev thing so i went to app data to find what was installed 
so i found in the Roaming folde Postman installed and has some data so i needed to open the database saved from post man or the requests to find the website so i installed Postman and tryed to load the db to it but i couldn't so i used an idea to copy all the files of the POST man to mine but alsio didn't work 
by ferther invastigating and searching i knew it's posible to do that but i have to get the post man right version 
so i kept checking to find in the main log file it had the version which was `7.0.6`

![image](/postImgs/CyCTF/11.png)

so I searched for it till i downloaded it from [postman site](https://dl.pstmn.io/download/version/7.0.6/windows64) now i have the right post man 
coping the IndexedDB folder to my postman folder i was able to get the requests sent by the user

![image](/postImgs/CyCTF/12.png)

it had post requests for some secret keys when i first looked i knew for sure that one of them is the flag
so i needed to decrypt it 
but i need a key while checking more in the requests i found a request to get the key and it had the file name and it's size 
the size info was very important for me to get the key 
![image](/postImgs/CyCTF/13.png)

so i knew the file name and size but it's not apperes on any part of the desk image 
but as we noticed how very tiny is this file so i checked it on the `MFT` File 
I didn't need to use anytools just open it on hexEditor and search for the `keyFile.txt` 

![image](/postImgs/CyCTF/14.png)

so we got the key `LuIT&HjIFwZQGsDW` back to the mail files we knew that the encryption was AES with CPC mode 
also we know that the IV was the reverse of the key and know we have every thing to get the flag
i deceded to try the secret1337 first as its the one the seems to be the flag 

```"secret1337": "6d7e4022adb41576dbe67f234dbec2f5fef1859256647c9bfb601feeb2c092cdd1e58d8253d13577bdea701fdbddd07c"```

using cyperchef to decrypt the AES we got the flag

![image](/postImgs/CyCTF/15.png)

```
CyCTF{p0stm4n_g0t_74mo_bust3d_r3alb4d!!}
```

#Geology 

## Challege Description

![image](/postImgs/CyCTF/18.png)

![image](/postImgs/CyCTF/19.png)

![image](/postImgs/CyCTF/20.png)


## Writeup
I didn't solve this one during the CTF but I solved it after

using dive over the image i as we are checking there was modification over the access.log is happend in this layer
 
`31badd250be9ebc7cef96087907d2174a95445289d8593e568adb89a4a36e474`
so i just downloaded the image layers and checked for the access.log of the apache server


```
docker save cyctf/geology > geology.tar
```
by untaring the file and going to the `31badd250be9ebc7cef96087907d2174a95445289d8593e568adb89a4a36e474` folder we got the complete access log 
so i just extracted it 
using any text viewer i went through the log to find there was a base64 `Q3lDVEZ7TDRZZXI1XzRuRF9sNHllcjVfMGZfQzBOdDQxbmVSMn0K` in the logs 

by decodeing it we have the flag

![image](/postImgs/CyCTF/22.png)

```
CyCTF{L4Yer5_4nD_l4yer5_0f_C0Nt41neR2}

```

# Mach

## Challege Description

![image](/postImgs/CyCTF/16.png)

## Writeup

for this one i didn't knew any thing about mobile but i knew my strings so i just
unzipped the ipa file using 7zip then did strings on the binary `re`
```
strings re
```
found hex data 
 
![image](/postImgs/CyCTF/17.png)

when decoded it gives the flag 

```
CyCTF{R3_15_4W350M3}
```

