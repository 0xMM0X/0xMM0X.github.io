+++
author = "MMOX"
title = "Alpha Box info-sec Hackathon Writeup"
date = "2021-08-07"
description = "this was a machine in the info-sec.live hackathon"
tags = [
    "CTF",
    "Writeups",
    "Machines",
	"info-sec",
	"Hackathon",
]
categories = [
    "Writeups",
    "CTF",
	"Machines",
]

favorite= true
show_comments= true
showToc= true
Tocopen= true
+++

![image](/postImgs/alpha/1.jfif)
# Challenge
We were provided with this info 
```
https://77.87.243.155
username: alpha
password: 900d1uck734m41ph4
```
![image](/postImgs/alpha/1.png)

and we will use it to login to the web kalIbox that we will use to solve the machine

# Writeup

I had a little idea that they have the machine on the same box so Ichecked the 
hosts to know the ip 

```
cat /etc/hosts
```
![image](/postImgs/alpha/2.png)

yup I was right the ip was there `192.168.204.3 funbox11`

let's scan it using nmap

I used this command

```
nmap -v -T4 -sC -sV -p-  192.168.204.3
```

there was a running service that caught my eye

![image](/postImgs/alpha/3.png)

and that was it Iuse metasploit to search for this service

```
serch ProFTPD 
```
![image](/postImgs/alpha/4.png)

I tried the last 2 payloads and only number 5 worked 
```
use 5
```
then Iwanted to see the payloads
by using `show payloads`

![image](/postImgs/alpha/5.png)

I used the reverse one `set payload 3`

![image](/postImgs/alpha/5.png)

also I set the RHOST , LHOST and the LPORT 

![image](/postImgs/alpha/6.png)

then I used `show options` to check if every thing was rigth

![image](/postImgs/alpha/7.png)

okay let's start the attack by using `run` 

![image](/postImgs/alpha/8.png)

it worked let's use `whoami` to know the user that Ihave


that's it I was root so let's find the flag

as alwys it was `/root/root.txt`

just by sending 
```
cd /root
cat root.txt
```
I got the flag

![image](/postImgs/alpha/flag.png)

And pingo...
that was it 