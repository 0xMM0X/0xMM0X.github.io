+++
author = "MMOX "
title = "Cyber Defenders - BankingTroubles"
date = "2021-03-06"
description = "Digital Forensic Memory Dump challenge Writeup "
tags = [
    "cyberdefenders",
    "Writeups",
    "Digital Forensics",
]
categories = [
    "Writeups",
    "DFIR",
	"Memory",
	"Digital Forensics",
]

favorite= true
show_comments= true
showToc= true
Tocopen= false
+++

![logo](/postImgs/cyberdefender/BankingTroubles/logo1.png)


# Description
	
	Company X has contacted you to perform forensics work on a recent incident that occurred. 
	One of their employees had received an e-mail from a co-worker that pointed to a PDF file. 
	Upon opening, the employee did not notice anything; however, they recently had unusual activity in their bank account.
	
	The initial theory is that a user received an e-mail, containing an URL leading to a forged PDF document.
	Opening that document in Acrobat Reader triggers a malicious Javascript that initiates a sequence of actions 
	to take over the victim's system.

	Company X was able to obtain a memory image of the employee's virtual machine upon suspected infection 
	and asked you to analyze the virtual memory and provide answers to the questions.

## Challenge Link :

	https://cyberdefenders.org/labs/43

- Supportive Tools:

	* [PDF-Tools](https://blog.didierstevens.com/programs/pdf-tools/)
	* [Malfind](https://github.com/volatilityfoundation/volatility/wiki/Command-Reference-Mal)
	* [libemu](http://libemu.carnivore.it/)
	* [Volatility](https://github.com/volatilityfoundation/volatility)
	* [Strings](https://linux.die.net/man/1/strings)
	* [Foremost](https://linux.die.net/man/1/foremost)
	* [Hexdump](https://blog.getfirebug.com/)
	* [Firebug](https://blog.getfirebug.com/)
	* [Objdump](https://linux.die.net/man/1/objdump)

# Writeup

## Q1 
	
	What was the local IP address for the victim's machine?	


![1](/postImgs/cyberdefender/BankingTroubles/1.png)

	./volatility.exe -f Bob.vmem imageinfo
	
first step we get the profile of the file and it was "WinXPSP2x86"

the first question was about the local ip so I am going to do a connections because netscan doesn't support  WinXPSP2x86 profile

	./volatility.exe -f Bob.vmem --profile=WinXPSP2x86 connections
	
![2](/postImgs/cyberdefender/BankingTroubles/2.png)

so that was simple the answer was :
	
	192.168.0.176
	
## Q2

	What was the OS variable value?
	
he was asking about the variable so i will use envars and grep any thing that has os

	 ./volatility.exe -f Bob.vmem --profile=WinXPSP2x86 envars |grep -i os

![3](/postImgs/cyberdefender/BankingTroubles/3.png)

yup that's the seconed answer

	Windows_NT

## Q3
	
	What was the Administrator's password?	

he want's the Admin password so hashdump then i will see if it's crackable 

	./volatility.exe -f Bob.vmem --profile=WinXPSP2x86 hashdump

![4](/postImgs/cyberdefender/BankingTroubles/4.png)

the hash was 
	
	8846f7eaee8fb117ad06bdd830b7586c
	
by using [crackstation](https://crackstation.net/) i was able to crack it 

![5](/postImgs/cyberdefender/BankingTroubles/5.png)

and that's it the anwer was 
	
	password

## Q4
	
	Which process was most likely responsible for the initial exploit?
	
so let's check the psxview

	./volatility.exe -f Bob.vmem --profile=WinXPSP2x86 psxview

![6](/postImgs/cyberdefender/BankingTroubles/6.png)

there was a process called "AcroRd32.exe" i think it's the sus one 

and i was right 
	
	AcroRd32.exe
	
## Q5
	
	What is the extension of the malicious file retrieved from the process responsible for the initial exploit?	

as the Sus process was Acrobat the extionstion os the file must be "pdf" 

	pdf

## Q6
	
	Suspicious processes opened network connections to external IPs. Provide the two external IP addresses. (comma-separated without spaces)

back to the connections plugin 

	./volatility.exe -f Bob.vmem --profile=WinXPSP2x86 connections

![7](/postImgs/cyberdefender/BankingTroubles/7.png)

the was 3 ip addresses that are the external but after I checked the pstree i knew the sus ones 
	
	./volatility.exe -f Bob.vmem --profile=WinXPSP2x86 pstree
	
![8](/postImgs/cyberdefender/BankingTroubles/8.png)

so i checked again the connections
	
	./volatility.exe -f Bob.vmem --profile=WinXPSP2x86 connections

![9](/postImgs/cyberdefender/BankingTroubles/9.png)
	
and the ips were 
	
	193.104.22.71,212.150.164.203

## Q7

	A suspicious URL was present in process svchost.exe memory. Provide the full URL that points to a PHP page hosted over a public IP (no FQDN).	
	
I will do a very stupid thing i will use strings and grep the url that starts with http:// and ends with php

	strings Bob.vmem |grep "^http://"|sort|uniq |grep "php"
	
![10](/postImgs/cyberdefender/BankingTroubles/10.png)

hell yeah it worked :LOL:
the url was 

	http://193.104.22.71/~produkt/9j856f_4m9y8urb.php

## Q8

	Extract files from the initial process. One file has an MD5 hash ending with "528afe08e437765cc".
	When was this file first submitted for analysis on VirusTotal?

the intial process hummmm i think it's the AcroRd32.exe so i will dump it 
	
	./volatility.exe -f Bob.vmem --profile=WinXPSP2x86 memdump -p 1752 -D .

then use foremost to extract the content 
	
	foremost 1752.dmp

there was a lot of data 

![11](/postImgs/cyberdefender/BankingTroubles/11.png)

but as the process is for pdf so i will check the pdf extractions

	md5sum * |grep 528afe08e437765cc

![12](/postImgs/cyberdefender/BankingTroubles/12.png)

so the complete hash was 
	
	f32aa81676c7391528afe08e437765cc


by using [virustotal](https://www.virustotal.com/gui/home/search) and search by hash i got this [report](https://www.virustotal.com/gui/file/0bd1a5731f70dbf77c03e09822e2b3d68a4f25064baff7371f281410114fc936/details) 

![13](/postImgs/cyberdefender/BankingTroubles/13.png)

and the answer was 
	
	2010-03-29 19:31:45

## Q9 
	
	What was the PID of the process that loaded the file PDF.php?

i didn't need to do any thing it's the AcroRd32.exe so the pid will be 
	
	1752

## Q10

	The JS includes a function meant to hide the call to function eval(). Provide the name of that function.	

we already know the sus pdf so I am going to use [peepdf](https://github.com/jesparza/peepdf) tool
it will help alot

	python peepdf.py 00601560.pdf
	echo 'extract js > all-javascripts-from-my.pdf' > xtract.txt 
	python peepdf.py -l -f -s xtract.txt 00601560.pdf
	cat all-javascripts-from-my.pdf

![14](/postImgs/cyberdefender/BankingTroubles/14.png)

with a little analysis i found the function name 
	
	HNQYxrFW

## Q11 

	The payload includes 3 shellcodes for different versions of Acrobat reader. Provide the function name that corresponds to Acrobat v9.	

my first extraction wasn't complete so i will try another tool called [pdf-pareser](https://github.com/smalot/pdfparser)

	python pdf-parser.py --search javascript --raw 00601560.pdf
	python pdf-parser.py --object 11 00601560.pdf
	python pdf-parser.py --object 1054 --raw --filter 00601560.pdf > malicious.js
	js malicious.js 

using notepad++ i opened the eval.001.log for analysis

at the last lines i saw this 

![15](/postImgs/cyberdefender/BankingTroubles/15.png)

and the anwer was

	XiIHG

## Q12 

	Process winlogon.exe hosted a popular malware that was first submitted for 
	analysis at VirusTotal on 2010-03-29 11:34:01. Provide the MD5 hash of that malware.	

as we know the infected process is winlogon so will do a malfind to it 
	
![19](/postImgs/cyberdefender/BankingTroubles/19.png)

now i know the address "" so let's dump it 

	volatility -f Bob.vmem --profile=WinXPSP2x86 malfind -D mal

there was 2 dumps that has the same address no problem

![20](/postImgs/cyberdefender/BankingTroubles/20.png)

i will get the hash of the 2 file and use virustotal to search for the correct one
	
	md5sum * |grep 0xa10000.dmp

![21](/postImgs/cyberdefender/BankingTroubles/21.png)

by seaching the first hash it has the date from the question  
	
![22](/postImgs/cyberdefender/BankingTroubles/22.png)

so that was it
	
	066f61950bdd31db4ba95959b86b5269
	
## Q13

	What is the name of the malicious executable referenced in registry hive '\WINDOWS\system32\config\software', and is variant of ZeuS trojan?	

created a file scan text file 

	./volatility.exe -f Bob.vmem --profile=WinXPSP2x86 filescan >f.txt

i opened the text file and finding any exe till  found this
	
![18](/postImgs/cyberdefender/BankingTroubles/18.png)

by googling it i found that it's one of ZeuS  variant
so i submitted it and it was right
	
	sdra64.exe

	
## Q14 

	The shellcode for Acrobat v7 downloads a file named e.exe from a specific URL. Provide the URL.	

i will try the same stupid approtch 
	
	strings Bob.vmem |grep "http://"|sort|uniq 

yes it still worked 

![17](/postImgs/cyberdefender/BankingTroubles/17.png)

the anwser was 
	
	http://search-network-plus.com/load.php?a=a&st=Internet Explorer 6.0&e=2


## Q15 

	The shellcode for Acrobat v8 exploits a specific vulnerability. Provide the CVE number.	

for the CVE number i will use [jsunpack-n](https://github.com/urule99/jsunpack-n)

	python jsunpack-n.py -v 00601560.pdf
	
![16](/postImgs/cyberdefender/BankingTroubles/16.png)

easy the CVE was 
	
	CVE-2008-2992

The lab cost my like 6 hours to solve but i really learned a lot so thanks for the lab creators  