+++
author = ["MMOX ","xElessaway"]
title = "MemLabs Writeup - Lab 6 (The Reckoning - Hard) "
date = "2021-03-01"
description = "Digital Forensic Memory Dump challenges Writeups "
tags = [
    "MemLabs",
    "Writeups",
    "Digital Forensics",
]
categories = [
    "Writeups",
    "DFIR",
	"Memory",
	"Digital Forensics",
]

favorite= true
show_comments= true
showToc= true
Tocopen= false
+++
![MemLabs-logo](/postImgs/MemLabs-logo.png)


|Lab   |   Challenge link   | difficulty| Writeup link|
|------|--------------------|------|-------------------------|
|Lab 1 | [Beginner's Luck](https://mega.nz/#!6l4BhKIb!l8ATZoliB_ULlvlkESwkPiXAETJEF7p91Gf9CWuQI70) | Easy |[Lab 1 ](https://www.mmox.me/posts/writeups/memlabs-lab1/)|
|Lab 2 | [A New World ](https://mega.nz/#!ChoDHaja!1XvuQd49c7-7kgJvPXIEAst-NXi8L3ggwienE1uoZTk)   | Easy |[Lab 2 ](https://www.mmox.me/posts/writeups/memlabs-lab2/)|
|Lab 3 | [The Evil's Den](https://mega.nz/#!2ohlTAzL!1T5iGzhUWdn88zS1yrDJA06yUouZxC-VstzXFSRuzVg) |Easy - Medium|[Lab 3 ](https://www.mmox.me/posts/writeups/memlabs-lab3/)|
|Lab 4 | [Obsession](https://mega.nz/#!Tx41jC5K!ifdu9DUair0sHncj5QWImJovfxixcAY-gt72mCXmYrE)      |Medium|[Lab 4 ](https://www.mmox.me/posts/writeups/memlabs-lab4/)|
|Lab 5 | [Black Tuesday](https://mega.nz/#!Ps5ViIqZ!UQtKmUuKUcqqtt6elP_9OJtnAbpwwMD7lVKN1iWGoec)   | Medium - Hard |[Lab 5 ](https://www.mmox.me/posts/writeups/memlabs-lab5/)|
|Lab 6 | [The Reckoning](https://mega.nz/#!C0pjUKxI!LnedePAfsJvFgD-Uaa4-f1Tu0kl5bFDzW6Mn2Ng6pnM)   |Hard|[Lab 6 ](https://www.mmox.me/posts/writeups/memlabs-lab6/)|

# Challenge description
	
	We received this memory dump from the Intelligence Bureau Department. They say this evidence
	might hold some secrets of the underworld gangster David Benjamin. This memory dump was taken 
	from one of his workers whom the FBI busted earlier this week. Your job is to go through the memory 
	dump and see if you can figure something out.FBI also says that David communicated with his
	workers via the internet so that might be a good place to start.
	
* Note: This challenge is composed of 1 flag split into 2 parts.
* The flag format for this lab is: inctf{s0me_l33t_Str1ng}

# Writeup

## Part 1

it was Win7SP1x64 so i did pslist

	./volatility.exe -f MemoryDump_Lab6.raw --profile=Win7SP1x64 pslist

![Lab6-1](/postImgs/lab6/1.png)

from the process list chrome.exe, firefox.exe and WinRAR.exe as active running processes.

so i used Volatilty plugins you can git it from [github](https://github.com/superponible/volatility-plugins)

	volatility --plugins=/home/mmox/vplug -f MemoryDump_Lab6.raw --profile Win7SP1x64 chromehistory
	
![Lab6-2](/postImgs/lab6/2.png)

	https://pastebin.com/RSGSi1hk

when i opend the link there was a google doc link

![Lab6-3](/postImgs/lab6/3.png)

	https://www.google.com/url?q=https://docs.google.com/document/d/1lptcksPt1l_w7Y29V4o6vkEnHToAPqiCkgNNZfS9rCk/edit?usp%3Dsharing&sa=D&source=hangouts&ust=1566208765722000&usg=AFQjCNHXd6Ck6F22MNQEsxdZo21JayPKug

while going throw the doc i found a mega link 

![Lab6-4](/postImgs/lab6/4.png)
	
	 https://mega.nz/#!SrxQxYTQ

it was missing the decryption key
in the pastebin link there was this text so
	But David sent the key in mail.
 
	The key is... :(  

so i will try something stupid 

	strings MemoryDump_Lab6.raw |grep -i "The key is"

![Lab6-5](/postImgs/lab6/5.png)

I was not expected that actually but work smarter not harder 
by using the key 

	zyWxCjCYYSEMA-hZe552qWVXiPwa5TecODbjnsscMIU

i was able to download the flag_.png file but it wasn't working 
so i checked the hex header

![Lab6-6](/postImgs/lab6/6.png)

really simple by replacing the "i" of "iHDR" with a captal "I" it worked


![flag](/postImgs/lab6/flag_.png)

and that was the first part :
	
	infctf{thi5_cH4LL3Ng3_!s_g0nn4_b3_?_

## Part 2 

it was a really long way to get the first half now let's get the second one

there was a winrar process running so we will check the files and grep RARs

	./volatility.exe -f MemoryDump_Lab6.raw --profile Win7SP1x64 filescan |grep ".rar"

![Lab6-7](/postImgs/lab6/7.png)

there was a rar calld flag.rar so let's dump it 

	./volatility.exe -f MemoryDump_Lab6.raw --profile Win7SP1x64 dumpfiles -Q 0x000000005fcfc4b0 -D .

![Lab6-8](/postImgs/lab6/8.png)

ops it's password protected so i tried a lot to get the password using "cmdline","cmdscan","greping text files",
"greping images","consoles "

but finally i found it in envars 

	./volatility.exe -f MemoryDump_Lab6.raw --profile Win7SP1x64 envars

![Lab6-9](/postImgs/lab6/9.png)

	easypeasyvirus

by using it i extracted flag2.png from the rar file 

![flag2](/postImgs/lab6/flag2.png)

and that's it the second half
 
	aN_Am4zINg_!_i_gU3Ss???_} 
	
it was the hardest one but i got the flag :

	infctf{thi5_cH4LL3Ng3_!s_g0nn4_b3_?_aN_Am4zINg_!_i_gU3Ss???_} 
	
