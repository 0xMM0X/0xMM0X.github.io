+++
author = "MMOX"
title = "Cyber Defenders - Ulysses"
date = "2022-06-14"
description = "A Linux server was possibly compromised and a forensic analysis is required in order to understand what really happened. Hard disk dumps and memory snapshots of the machine are provided in order to solve the challenge. "

tags = [
    "cyberdefenders",
    "Writeups",
    "Digital Forensics",
]
categories = [
    "Writeups",
    "DFIR",
	"Memory",
	"sda",
	"Digital Forensics",
]

favorite= true
show_comments= true
showToc= true
Tocopen= false
+++

![logo](/postImgs/cyberdefender/Ulysses/logo.png)

# Description
A Linux server was possibly compromised and a forensic analysis is required in order to understand what really happened. Hard disk dumps and memory snapshots of the machine are provided in order to solve the challenge.

## Challenge Files:

* victoria-v8.kcore.img: memory dump done by dd’ing /proc/kcore.
* victoria-v8.memdump.img: memory dump done with memdump.
* Debian5_26.zip: volatility custom Linux profile.

## Challenge Link :

	https://cyberdefenders.org/labs/41

- Supportive Tools:
* [Volatilty 2.6](https://github.com/volatilityfoundation/volatility)
* [FTK imger](https://go.exterro.com/l/43312/2022-01-21/f6h1s3)
* [HxD](https://mh-nexus.de/en/hxd/)

# Writeup

## Q1
	
	The attacker was performing a Brute Force attack. What account triggered the alert?

using FTK imager I opened the `victoria-v8.sda1.img` and in the question, there was a mention of an alert so let's check the logs

in the `/var/log/auth.log` file there is multiple tries for a user named Ulysses so the answer is :
	
> ulysses

## Q2

	How many were failed attempts there?

i extracted the `auth.log` file using this command `cat auth.log |grep -i "failed"|wc` i got the number 33

when I tried to submit it said wrong so I rechecked the file to find that there was an extra field for the root
so the answer was:

> 32

## Q3

	What kind of system runs on the targeted server?

that was an easy question, The answer was clear in the file `/etc/issue.net` and it was :

> Debian GNU/Linux 5.0

## Q4 

	What is the victim's IP address?
 
now the interesting stuff dealing with the memory 
there was a Linux profile included in the challenge files so after adding it to the volatility path I used
`python2 volatility/vol.py --info |grep -i debian` to get the profile name so let's start digging into the dump 


![1](/postImgs/cyberdefender/Ulysses/1.png)

the question was about the IP so let's try the `linux_netstat` plugin 

using this command `python2 volatility/vol.py -f victoria-v8.raw --profile=LinuxDebian5_26x86 linux_netstat`
there was the IP :

> 192.168.56.102

## Q5
	
	What are the attacker's two IP addresses? Format: comma-separated in ascending order

while using the same command as the question before only 2 IP addresses were accessing the system

> 192.168.56.1,192.168.56.101

## Q6 
	
	What is the "nc" service PID number that was running on the server?

nc is a network tool so I don't need to run the pslist command as it appeared to be the last connection and has the PID of:

> 2169

## Q7

	What service was exploited to gain access to the system? (one word)

okay to check the services we need to use the `linux_psaux` plugin and the process was :

> exim4

## Q8 
	
	What is the CVE number of exploited vulnerability?
	
These kind of questions I prefer the least it requires only google searching and the answer was:
	
> CVE-2010-4344

## Q9 

	During this attack, the attacker downloaded two files to the server. Provide the name of the compressed file.

It is easier to search for files in the sda1 so let's get back to it. the first thing I always check is the `/tmp` folder
and it wasn't hard the answer was:

> rk.tar

## Q10
	
	Two ports were involved in the process of data exfiltration. Provide the port number of the highest one.

using the same command as question 4 the answer is:

> 8888

## Q11

	Which port did the attacker try to block on the firewall?

I extracted the tar from question 9 and checked the install.sh file 

there was only 1 port so it was clear :

> 45295

and that was it. 