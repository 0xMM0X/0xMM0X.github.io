+++
author = "MMOX "
title = "Cyber Defenders - Patrick"
date = "2022-12-08"
description = "Digital Forensic IOS challenge Writeup "
tags = [
    "cyberdefenders",
    "Writeups",
    "Digital Forensics",
	"IOS",
]
categories = [
    "Writeups",
    "DFIR",
	"IOS",
	"Digital Forensics",
]

favorite= true
show_comments= true
showToc= true
Tocopen= false
+++

![logo](/postImgs/cyberdefender/Patrick/logo1.png)


# Description

	This image was captured from an iPhone of a user who likes to play video games, especially Minecraft, 
	and communicates with friends. But is this user doing something they shouldn't be?. We need to identify 
	any kind of anomaly behavior done by this user.

## Challenge Link :

	https://cyberdefenders.org/blueteam-ctf-challenges/96
	
- Supportive Tools:

	* [CyberChef](https://gchq.github.io/CyberChef/)
	* [iLEAPP](https://github.com/abrignoni/iLEAPP)
	* [dcode](https://www.digital-detective.net/dcode/)
	* [DB Browser for SQLite](https://sqlitebrowser.org/)
	* [unfurl](https://github.com/obsidianforensics/unfurl)
	* [MacForensics PList Deserializer](https://github.com/ydkhatri/MacForensics/tree/master/Deserializer)
	
# Writeup

## Q1 
	
	1: Personal List! -> How many items were on Patrick's shopping list?

Before i started anything i just used iLEAPP over the whole image and it genrated a full report so it makes our analysis easier

![logo](/postImgs/cyberdefender/Patrick/1.png)

by opening the `index.html` you will find that most data got parsed for the first question he was asking abnout the Grocery list
so i just went to the note 

![logo](/postImgs/cyberdefender/Patrick/2.png)

just by counting the item you got the Answer 

	
## Q2

	Cache Me if You Can -> What was the last position of the phone?

for this one i couldn't find it any where in the parsed report so i did some googling to find that it's stored in 
`com.apple.routined\Cache.sqlite`  so I went to check this file using sqllite viewer i opend the file in the `ZRTCLLOCATIONMO`
it had multible locations so i just sorted them by the time stamp to get the last location 
buting them to the answer format and we got the answer

![logo](/postImgs/cyberdefender/Patrick/3.png)

## Q3
	
	Take your left shoe off... Now put it back on -> When was the last reboot performed?

Back to the iLEAPP Report i went to the `Mobile Instalation Logs` then the `State-Reboots` also using the time stamp to sort them 
easy we have the answer

![logo](/postImgs/cyberdefender/Patrick/4.png)

## Q4
	
	Red or Alive -> What time was Patrick's Reddit account created?

I was stucked in this question until AXIOM finshed analizing and it gaved us an inshight about it so by just searching for riddet 
i got the path of the reddit files
`private\var\mobile\Containers\Shared\AppGroup\C0D4CE88-705C-4BBD-9900-0CC64DAF8243\Library\Application Support\accounts`

using the Deserializer that was provided in the description
```
python3 Deserializer/deserializer.py -j ivu21eum

```
![logo](/postImgs/cyberdefender/Patrick/13.png)

we got the time and the username whitch is `PogProgrammer`

## Q5
	
	Hanging on by a thread -> Which application was uninstalled?

the `Apps - Uninstalled report` was the place to look i found the bundle id Just putting it into google i got the app name

![logo](/postImgs/cyberdefender/Patrick/6.png)


## Q6
	
	Was the message Redd(it)? -> What was the content of the message in the last notification received from Reddit?

From the iLEAPP Report i checked the `iOS Notificatons report` it had alot of notification so by sorting using the time stamp
then checking for the last reddit one we got the answer

![logo](/postImgs/cyberdefender/Patrick/7.png)

## Q7

	Pigment of your imagination ->	What is the hex code of the color assigned to work events?

this was an easy question just go to the `callender list report` check for the work list you will get the hex 

![logo](/postImgs/cyberdefender/Patrick/8.png)

## Q8
	Sponsored post ->How many promotion emails were left unread?
by checking the `Gmail - Label Details report` searching for the promo label easy we have the number

![logo](/postImgs/cyberdefender/Patrick/8.png)

I got that is 23 but it wasn't accepted I don't know why so I will recheck the manualy to see
after I did alot of searching for more than an hour i only got 23 so I checked for a writeup for this challenge to find that the 
answer is 21 and that was very weired for me as the writeup i checked got it by brute forcing and the other knows the answer from
the CTF itself so i will put the answer clear for you if you stucked the same as me 

> 21

## Q9 
	
	To infinity and beyond! -> What alarm sound did Patrick choose?

also easy just check the `Alarms report` 

![logo](/postImgs/cyberdefender/Patrick/9.png)


## Q10
	
	Poor Reception -> When did the cellular service of this device expire?

at this point Axiom  was finally done analizing the data so i switched to it as it's more powerfull Searching for the keyword `expire`
so I found that there is only a massages from Total Wireliess about the expire date

![logo](/postImgs/cyberdefender/Patrick/11.png)

## Q11 

	Locate how you spend your time -> Which application had the most amount of screentime?
by checking the app usage tab and sorting by files it gaved me safari when i tried to submit it was wrong 
so I knew where the sql file was so i opend it useing sql lite 

`private\var\mobile\Library\CoreDuet\Knowledge\knowledgeC.db`

so by doing submition of all semilar apps in focus we got the App name 

![logo](/postImgs/cyberdefender/Patrick/12.png)

## Q12 

	TLDR: Kigarumis are scary -> What animal is Patrick's Reddit avatar wearing?

back to the json file that we created in question 4  
there was a linnk for the avatar 
![avatar](https://i.redd.it/snoovatar/avatars/4087a416-0590-445b-ac6a-28b3e810b763.png)
I took a while to know what is this anaimal 😅
and it was an owl 

![logo](/postImgs/cyberdefender/Patrick/15.jpg)


## Q13

	A day without sunshine -> What is the name of the GIF sent to Patrick in a message on Bumble?
I rememberd that i noticed the bumble massages in the iLEAPP report so i opened it to find the massages
in the massages there was a giphy link 
	
	https://giphy.com/embed/cXCVTR1wUn1a8	

the name of the gif is the answer

- but remember to remove the spaces and add the . before thegif

## Q14 

	What the .heic? -> Which cardinal direction was Patrick moving when he took a live photo?

I actually solved this one by guessing as we only have 4 direction with my first guess i knew it was east

## Q15
	Location, Location, Location -> When did Patrick first search for a website revealing his IP address?

Back to axiom in the google search tab there was a search for `what is my IP`

	https://www.google.com/search?q=whatsmyip.com&amp;client=safari&amp;hl=en-us&amp;ei=MiXkYc-ZMLOfptQPgvCg2Ak&amp;oq=whatsmyip.com&amp;gs_lcp=ChNtb2JpbGUtZ3dzLXdpei1zZXJwEAMyBQgAEIAEMgUIABCABDIFCAAQgAQyBwgAEIAEEAoyBggAEAoQHjIECAAQHjIGCAAQChAeMgQIABAeOgcIABBHELADOg0ILhDHARCjAhCwAxBDOgcIABCwAxBDOg4IABCPARDqAhCMAxDlAjoFCAAQkQI6DgguEIAEELEDEMcBENEDOgsILhCABBDHARCjAjoOCC4QgAQQsQMQxwEQowI6CwguEIAEELEDEIMBOhEILhCABBCxAxCDARDHARDRAzoECAAQQzoLCC4QgAQQxwEQrwE6BwgAELEDEEM6CAgAEIAEELEDOgoIABCxAxCDARBDOgcILhCABBAKOggIABCxAxCDAToLCAAQgAQQsQMQgwE6BAgAEAM6CAgAEIAEEMkDOgUIABCSAzoLCAAQgAQQsQMQyQM6BwgAELEDEAo6CggAELEDEIMBEApKBAhBGABQ7A9YuEdg4lBoCnABeACAAasBiAGlDJIBBDE0LjOYAQCgAQGwAQ_IAQvAAQE&amp;sclient=mobile-gws-wiz-serp

using [unfurl](https://dfir.blog/unfurl/) we got the time stamp

![logo](/postImgs/cyberdefender/Patrick/14.png)

finally we reatched to the last step  using [CyberChef](https://gchq.github.io/CyberChef/#recipe=From_UNIX_Timestamp('Microseconds%20(%CE%BCs)')&input=MTY0MjM0MTY4Mjc4OTcxMQ) to decode the Timestamp 

THE CHALLENGE IS COMPLETED 

![logo](/postImgs/cyberdefender/Patrick/16.png)
 
it was really fun and i really enjoyed some of the question