+++
author = "MMOX"
title = "Cyber Defenders - AzurePot"
date = "2022-06-14"
description = "This Ubuntu Linux honeypot was put online in Azure in early October to watch what happens with those exploiting CVE-2021-41773."

tags = [
    "cyberdefenders",
    "Writeups",
    "Digital Forensics",
]
categories = [
    "Writeups",
    "DFIR",
	"Memory",
	"sda",
	"Digital Forensics",
]

favorite= true
show_comments= true
showToc= true
Tocopen= false
+++

![logo](/postImgs/cyberdefender/AzurePot/logo.png)

# Description
```

This Ubuntu Linux honeypot was put online in Azure in early October to watch what happens with those exploiting CVE-2021-41773.

Initially, there was a large number of crypto miners that hit the system. You will see one cron script meant to remove files named kinsing in /tmp. This was a way of preventing these miners so more interesting things could occur.

```

## Challenge Files:

* sdb.vhd.gz  VHD of the main drive obtained through an Azure disk snapshot
* ubuntu.20211208.mem.gz – Dump of memory using Lime
* uac.tgz – Results of UAC running on the system

## Challenge Link :

	https://cyberdefenders.org/blueteam-ctf-challenges/101

- Supportive Tools:
* [Volatilty 2.6](https://github.com/volatilityfoundation/volatility)
* [FTK imger](https://go.exterro.com/l/43312/2022-01-21/f6h1s3)
* [Notepad++](https://notepad-plus-plus.org/downloads/)

# Writeup

I will only provide the steps to get the answers no clear answer in this writeup

## Q1
	
	File => sdb.vhd
	There is a script that runs every minute to do cleanup. What is the name of the file?

using FTK imager I opened the `Sdb.vhd` file as we know the cron tabs is the place that we shloud look for so i went directly to 
`/var/spool/cron/crontabs/` there was 1 file named root when i opend it i got the answer 


## Q2

	File => sdb.vhd
	The script in the Q#1 terminates processes associated with two Bitcoin miner malware files. What is the name of 1st malware file?

as now we got the script name and location i went to check it so it search for 2 process and kills them the answer is the first process

![1](/postImgs/cyberdefender/AzurePot/1.png)


## Q3

	File => sdb.vhd
	The script in Q#1 changes the permissions for some files. What is their new permission?

that was an easy question, The answer was clear in the script just check the `chmod` Command

## Q4 

	File => sdb.vhd
	What is the sha256 of the botnet agent file?
 
I couldn't find it in the tmp so after a long search i found it in the `/var/tmp` 
I wanted to skip some steps so i just uploaded the file into virus total and got the answer for Q4 and Q5

## Q5
	
	File => sdb.vhd
	What is the name of the botnet in Q#4?

it's the first result on virus total

## Q6 
			
	File => sdb.vhd
	What IP address matches the creation timestamp of the botnet agent file in Q#4?


after having a look on some reports i know it's apache related so i went to check the apache logs `/var/log/apache2/access_log`

By the Power of strings and grep it was easy all u need to do is read all the file and grep anything related to dk86 file 

## Q7
	
	File => sdb.vhd
	What URL did the attacker use to download the botnet agent?
it's fair to assume that the attacker have the file name in the url so i tried to grep any url ends with the botnet name and vola it's there


## Q8 
			
	File => sdb.vhd
	What is the name of the file that the attacker downloaded to execute the malicious script and subsequently remove itself?
	
when we got the url u will notice that the attacker used `wget ` to download the file so i grepped every thing related to the wegt command on the `/var/log/apache2/err_log file` file 
u will notice there is .sh file download which conatins encoded text when u decode it u will no the answer


## Q9 

	File => sdb.vhd
	The attacker downloaded sh scripts. What are the names of these files?

in the same file that u got the answer for the Q8 u shoud have all what u need to answer this too 

Here we have reached the ending of the questions related to the  `sdb.vhd` file 

## Q10
	
	File => UAC
	Two suspicious processes were running from a deleted directory. What are their PIDs?

let's check process dirctory under the live_response we are searching for something running from the deleted directory so let's check the `lsof_-nPl.txt` 
it's the first 2 process ids 

> Quick note remmber to add space after the first pid , XD

## Q11

	File => UAC
	What is the suspicious command line associated with the 2nd PID in Q#10?

u have the PID just grep it from this file `ps_-ef.txt` u will get the answer

## Q12 

	File => UAC
	UAC gathered some data from the second process in Q#10. What is the remote IP address and remote port that was used in the attack?

let's check the procees id folder in the proc dir with `grep -Ri Remote` u will get the answer

## Q13
		
	File => UAC
	Which user was responsible for executing the command in Q#11?

this question order i think is wrong cause once you have the answer for Q11 u have the answer for this one

## Q14 

	File => UAC
	Two suspicious shell processes were running from the tmp folder. What are their PIDs?

like Q10 u will grep tmp over the file and u will 4 or 5 pids i will leave it to u to figure out which one is needed

## Q15 
		
	File => ubuntu.20211208.mem
	What is the MAC address of the captured memory?

for this fun part u will need to create a profile for this dump but i already have it so I will dig in quicky 

so let's go i just ran vol2 with the linux_ifconfig you will get the answer

```bash
vol2 -f ubuntu.20211208.mem --profile=LinuxUbuntu-azurex64 linux_ifconfig
```


## Q16 

	File => ubuntu.20211208.mem
	From Bash history. The attacker downloaded an sh script. What is the name of the file?	

just by running this command 
```bash
vol2 -f ubuntu.20211208.mem --profile=LinuxUbuntu-azurex64 linux_bash | gerp ".sh"
```

u will have the answer

and that's it , also i think the last 2 question was just there for the player to create the profile as it would be the hardes part of the challenge and GG the challenge is over

![2](/postImgs/cyberdefender/AzurePot/2.png)
