+++
author = "MMOX "
title = "Ryuk Ransomware Analysis Memory Detection - Part 1 "
date = "2021-04-06"
description = ""
tags = [
    "Ransomwares",
    "Ryuk",
    "Digital Forensics",
]
categories = [
    "Ransomwares",
    "DFIR",
	"Memory",
	"Digital Forensics",
]

favorite= true
show_comments= true
showToc= true
Tocopen= false
+++

![logo](/postImgs/Ryuk/Ransomware.jpg)


**Ryuk** is a ransomware which encrypts its victim's files and asks for a ransom via bitcoin to release the original files. 
It is has been observed being used to attack companies or professional environments. 
Cybersecurity experts figured out that Ryuk and Hermes ransomware shares pieces of codes. 
Hermes is commodity ransomware that has been observed for sale on dark-net forums and used by multiple threat actors.

And I am going to do some analysis form a forensics perspective 

# Lab Setup

I used windows7X64bit / 512MB RAM on VMware to run the malware sample and allowed it to communicate over the network
 without using a fakedns or fakenet, then I suspended the VM after 5 minutes of execution and Got the Dump.
 
And here is the Dump if you want to check it 


 - **Sample :**[Download](https://drive.google.com/file/d/1tbMB-FRbCrgD_0LPVEB6-79Wa1Toedgt/view?usp=sharing)

 - **Ryuk.vmem MD5 :** 218a863015b17990d90593f24a8796da
 
 - **Ryuk.7z MD5 :** 72c36763d1bd2fdca8a09d8919f32723


# Analysis
i will be using volatity 2 for this dump  
Let's Start the Analysis , the Image info was "Win7SP1x64"

# Process check

I use volatility psxview so if there were any kind of hidden processes or rootkits, it can be detected


![1](/postImgs/Ryuk/psxview.png)

There was some suspious processes but not hidden but we still need to see how they related by using psscan 

```
volatility -f Ryuk.vmem --profile=Win7SP1x64 pstree -p 2608 --output dot --output-file psscan.dot
```

```
dot -Tpng psscan.dot -o psscan.png
```

![1](/postImgs/Ryuk/psscan.png)

> Note: this is not the hole output i just snipped the part that related to the process 2608

the Ryuk.exe process opend 5 process 2 of them terminated "net.exe", "net1.exe" at  `2021-04-06 13:44:52 UTC+0000` 
 and 3 are still running "PNLjIeUwVlan","EyDIbTsWJrep","xFCMVqsIQlan"
 so I am going to check the 3 running processes `956,2380,2008`

# Privileges

After we establised the malware processes let's check thier privileges 

```
volatilty --plugins=plugins -f Ryuk.vmem --profile=Win7SP1x64 privs  -p 956,2380,2008 |grep Enabled
```

![1](/postImgs/Ryuk/privs.png)

Nothing seems interesting 
so let's check the 2 terminated processes but to do that we need to use the offset 
for the `net1 ` with the pid `1480` the offset was `0x000000001ecc3a30` 
for the `net2 ` with the pid `2668` the offset was `0x000000001db23b30` 

```
volatility --plugins=plugins -f Ryuk.vmem --profile=Win7SP1x64 privs  --offset=0x000000001ecc3a30

volatility --plugins=plugins -f Ryuk.vmem --profile=Win7SP1x64 privs  --offset=0x000000001db23b30
```
but as expected there was no information as the processes terminated

# Handels 
the important handles are files, keys, mutex then we will check the vads 
if we found any kind of process injection we can go back to handles and follow the threads.


## Process 2608

### Files

	volatility --plugins=plugins -f Ryuk.vmem --profile=Win7SP1x64 handles -p 2608 -t file


![1](/postImgs/Ryuk/p2608-files.png)

as we can see the process opened sevral file handles but there is 2 interesting files 
`R000000000006.clb` and `x86_microsoft.windows.common-controls_6595b64144ccf1df_6.0.7601.17514_none_41e6975e2bd6f2b2`

and the both located in the Windows folder 


### keys

	volatility --plugins=plugins -f Ryuk.vmem --profile=Win7SP1x64 handles -p 2608 -t key


![1](/postImgs/Ryuk/p2608-keys.png)

I don't really know what every key does so i couldn't know what key sholud i check
so the i will check the keys which is not used by any other processor used by all the malware process only
 or mutual between the malware and important system process

> Note : The Keys are paged  so we can’t find all the keys resident in memory so i will check the VM to see all the keys

but to show what is paged and what is not i used 
	
	volatility -f Ryuk.vmem --profile=Win7SP1x64 objtypescan


![1](/postImgs/Ryuk/objtypescan.png)

	
i tried to find any thing interesting but couldn't

- IMAGE FILE EXECUTION OPTIONS :  safe

- HWORDER : safe

- VERSIONS :  safe

- SESSION MANAGER :  safe

- MACHINE :  safe

- CUSTOMLOCALE : safe

so i started to check the users hive but also i couldn't find any thing 


### Mutant / Mutex :

	volatility --plugins=plugins -f Ryuk.vmem --profile=Win7SP1x64 handles -p 2608 -t mutant 


![1](/postImgs/Ryuk/p2608-mutant.png)

we can't view all mutexes because its a disk paged objects like keys

but we have the some of it here 
as we can see it has 5 uniqe mutex

## Process 2008, 2380 , 956

### Files

There was nothing interesting in the files 

### Keys

Also the keys has nothing

### Mutant / Mutex :

Paged so we got nothing

# Network


	volatility --plugins=plugins -f Ryuk.vmem --profile=Win7SP1x64 netscan 


![1](/postImgs/Ryuk/Conn-1.png)
![1](/postImgs/Ryuk/Conn-2.png)

there was a lot of system conntections 

**The Connected IPs**
- 56.235.192.2
- 127.0.0.1 (LocalHost)

# DLLs

## Ryuk.exe 2608

	volatility --plugins=plugins -f Ryuk.vmem --profile=Win7SP1x64 dlllist -p 2608

![1](/postImgs/Ryuk/dlls-2608.png)

nothing is interesting in those Dlls, it uses only the system DLLs

## PNLjIeUwVlan.exe 2008 

	volatility --plugins=plugins -f Ryuk.vmem --profile=Win7SP1x64 dlllist -p 2008

![1](/postImgs/Ryuk/dlls-2008.png)

also the same nothing interesting 

## xFCMVqsIQlan.exe 2380 

	volatility --plugins=plugins -f Ryuk.vmem --profile=Win7SP1x64 dlllist -p 2380

![1](/postImgs/Ryuk/dlls-2380.png)

also nothing interesting 


## EyDIbTsWJrep.exe 956 

	volatility --plugins=plugins -f Ryuk.vmem --profile=Win7SP1x64 dlllist -p 956

![1](/postImgs/Ryuk/dlls-956.png)

also nothing interesting 

# Event Logs

Mabye I missed somthing so I am going to check the event log

	volatility -f Ryuk.vmem --profile=Win7SP1x64 dumpfiles --regex .evtx$ --ignore-case --dump-dir Logs



![1](/postImgs/Ryuk/evtlogs.png)

after the scan finshed i tried file to see which data is event and which isn't

	file Logs/*


![1](/postImgs/Ryuk/logfile.png)

as we can see some of the file is data instead of MS Windows Event Vista Event Log
because either the header for the log or the log itself was swapped out of memory at the 
time of acquisition. In either case, we should investigate these files to see if we can 
find partial records. 

i used [evtx_dump](https://github.com/omerbenamram/evtx) Tool to se the events 
but most of them are empty so it also has nothing
	
	evtx_dump.py Logs/file.768.0xfffffa80028cb310.vacb
	
![1](/postImgs/Ryuk/evtdump.png)


and that's the end of my first part 
Any feedback is welcomed 

see u in Next parts 

![s](https://media.giphy.com/media/l1J3IHzSUmCpXThqo/giphy.gif)